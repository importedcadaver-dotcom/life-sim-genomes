"""CLI: python -m biosphere ..."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from .simulation import Config, World


def simulate(args: argparse.Namespace) -> None:
    cfg = Config(founders=args.founders, max_population=args.max_population,
                 sensor_mode=args.sensor_mode, allow_mutation=not args.no_mutation,
                 mutation_strength=args.mutation_strength, growth_rate=args.growth_rate,
                 resource_patchiness=args.patchiness)
    world = World.load(args.resume) if args.resume else World(cfg, seed=args.seed)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    with (out / "metrics.csv").open("w", newline="", encoding="utf-8") as metrics, \
         (out / "lineage.csv").open("w", newline="", encoding="utf-8") as lineage:
        writer = csv.DictWriter(metrics, fieldnames=list(world.stats().keys()))
        writer.writeheader()
        lw = csv.DictWriter(lineage, fieldnames=["tick", "kind", "id", "parent_id", "generation", "cause"])
        if args.events:
            lw.writeheader()
        writer.writerow(world.stats())
        for _ in range(args.steps):
            stats = world.step()
            if args.events:
                for event in world.last_events:
                    lw.writerow(event)
            if world.tick % args.sample_every == 0 or world.population == 0:
                writer.writerow(world.stats(stats["births"], stats["deaths"]))
            if world.population == 0:
                print(f"Population went extinct at tick {world.tick}.")
                break
    world.save(out / "world.npz")
    report = {"seed": world.seed, "steps_completed": world.tick,
              "config": vars(world.config), "final": world.stats(),
              "death_causes": world.death_causes}
    (out / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["final"], indent=2))
    print(f"Files written to {out.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(prog="biosphere", description="An evolving digital ecosystem")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("run", help="Headless reproducible evolution")
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--steps", type=int, default=3000)
    p.add_argument("--founders", type=int, default=180)
    p.add_argument("--max-population", type=int, default=900)
    p.add_argument("--sensor-mode", choices=("normal", "blind"), default="normal")
    p.add_argument("--no-mutation", action="store_true")
    p.add_argument("--mutation-strength", type=float, default=0.28)
    p.add_argument("--growth-rate", type=float, default=0.030)
    p.add_argument("--patchiness", type=float, default=1.0)
    p.add_argument("--resume", type=Path)
    p.add_argument("--sample-every", type=int, default=25)
    p.add_argument("--events", action="store_true", help="Save every birth/death to lineage.csv")
    p.add_argument("--output", default="results/run")
    p.set_defaults(func=simulate)
    v = sub.add_parser("view", help="Pygame ecosystem viewer")
    v.add_argument("--seed", type=int, default=1)
    v.add_argument("--resume", type=Path)
    v.add_argument("--max-population", type=int, default=900)
    v.set_defaults(func=lambda a: __import__("biosphere.viewer", fromlist=["view"]).view(a))
    e = sub.add_parser("experiment", help="Multi-seed controlled selection experiment")
    e.add_argument("--seeds", type=int, default=6)
    e.add_argument("--steps", type=int, default=2200)
    e.add_argument("--probe-ticks", type=int, default=260)
    e.add_argument("--output", type=Path, default=Path("results/experiment"))
    e.set_defaults(func=lambda a: __import__("biosphere.experiment", fromlist=["run_experiment"]).run_experiment(a))
    args = parser.parse_args()
    if hasattr(args, "sample_every") and args.sample_every < 1:
        parser.error("--sample-every must be positive")
    args.func(args)

if __name__ == "__main__":
    main()
