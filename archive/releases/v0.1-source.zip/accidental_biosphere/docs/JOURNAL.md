# Research journal

### 2026-11-02 — Background and build decision

Reviewed Tierra (digital self-replicating programs), Avida (controlled digital-evolution studies), and Polyworld (neurally controlled organisms in an ecology). Chose a simpler visible sensorimotor model with NumPy simulation and a separate Pygame window. Aim: make claims only about heritable adaptive controller changes, not synthetic cognitive life.

### 2026-11-02 — First code tests: patch saturation failure

Initial small-world terrain generator used 27 random overlapping resource hills regardless of world size. On a 22×18 test map, practically every cell hit the maximum capacity. Different random seeds became indistinguishable, and a test caught it. **Fix:** scale the number of hills to world area. Also changed sensor readings from percentage of maximum capacity to **absolute food stock**; percentages initially gave identical sensor readings everywhere on a fully replenished map, erasing the very gradient being studied. These are architectural corrections, not evolutionary discoveries.

### 2026-11-02 — Pilot: repeated tests

At 900 training ticks over seeds 1–3, evolved controllers outperformed initial founders in novel landscapes. However, no-mutation groups did better than mutating groups in all three of these short pilot runs. **Action:** explicitly include no-mutation controls and founder-blind trials before the primary six-seed exploratory comparison. Do not assert beneficial mutation just because a system evolves.

### 2026-11-02 — Completed Experiment 001

Ran 6 seeds × 1,200 training ticks, with six matched control treatments evaluated for 180 ticks in fresh landscapes. Average evolved harvest = 0.5873; founder = 0.4621. Removing evolved environmental senses reduced performance to 0.5244. Evolution increased sensor benefit by +0.0286 (paired bootstrap 95% interval +0.0167 to +0.0398). Mutation effect indistinguishable from zero at this scale. An additional observation: average motor speed was 0.488 for founders and 0.713 for evolved genomes across matched common gardens. This supports a simple behavioral interpretation of increased resource access through exploration, not demonstrated food-directed turning. Full methods: `EXPERIMENT_001.md`.

**Interpretation:** selection improved heritable controller behavior in a way useful for collecting resources. More evidence is needed to isolate the strategy; no cooperation or complex intelligence can be inferred.

### 2026-11-02 — Engineering validation

Added tests for deterministic seeding, resource allocation under crowding, reproduction lineage integrity, exact checkpoint continuation, blinding, extinction, mutation-disabled inheritance, invalid config, no-food energy decline, population cap, common-garden repeatability, and saved-observable recovery. Built an actual-state plotting utility. Viewer logic is written and syntax-checked, but **cannot be runtime-smoke-tested here** because Pygame isn't installed and package installation could not reach its repository.

### Open findings and failed expectations

- It was premature to expect beneficial new mutations to reliably outperform standing-variation selection in ~1,200 steps. At this horizon they did not.
- Improvement in total food collection does not tell us *how* organisms move. The next investigation must measure the stimulus-response controller directly and use richer ablations.
- The first pilot showed that simple resource-rich ecologies can quickly reach the simulation's 900-organism cap. This makes demographic selection and crowding important confounders worth manipulating.
- Despite thousands of births, the prototype has not demonstrated communication, distinct social roles or emergent predators. We will not add labels to ordinary movement to make it sound more impressive.
