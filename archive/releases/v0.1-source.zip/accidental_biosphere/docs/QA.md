# QA and verification

**Last automated test run: 2026-11-02.**

| Check | Status |
| --- | --- |
| Python modules syntax check | PASS (`compileall`) |
| Identical seeds replay identically | PASS |
| Different seeds generate different terrain | PASS |
| Resource cell never becomes negative under many overlapping agents | PASS |
| Birth uses valid parent IDs and generation increment | PASS |
| Simulated reproduction cannot push above population cap | PASS |
| Checkpoint continuation equals uninterrupted simulation | PASS |
| New checkpoint preserves aggregate measurements | PASS |
| Senses can be removed for intervention | PASS |
| Extinct population remains extinct | PASS |
| Mutations disabled means genome copies are exact | PASS |
| Unphysical/invalid configurations rejected | PASS |
| No food plus metabolism reduces energy | PASS |
| Repeated common-garden evaluation with same seed is deterministic | PASS |
| Full headless CLI run and CSV/NPZ export | PASS |
| Six-seed common-garden experiment outputs data and charts | PASS |
| Real saved-world snapshot rendering | PASS |
| Pygame viewer actually launches and accepts controls | **UNVERIFIED**: Pygame package unavailable in this environment |
| Windows .bat actually launches on Windows | **UNVERIFIED**: Linux runner cannot reproduce Windows environment |
| Distribution as a precompiled Windows `.exe` | **NOT PROVIDED** |
| External review by domain scientist | **NOT DONE** |

Unit tests are in `tests/test_simulation.py`. Run `python -m pytest -q` after extracting.

### Notes

- Deterministic tests are for the same code/runtime environment. Numerical results may vary across NumPy versions.
- Long runs reached the cap of 900 individuals; more tests are needed to quantify any cap-induced evolutionary effect.
- Stored checkpoints include NumPy arrays and serialized JSON RNG state; loading uses `allow_pickle=False`.
- Results are exploratory; the six training seeds are the independent units of replication.
- The first tested terrain issue is described transparently in `JOURNAL.md`.
