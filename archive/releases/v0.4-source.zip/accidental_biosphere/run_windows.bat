@echo off
setlocal
cd /d "%~dp0"
py -3 -c "import numpy, pygame, matplotlib" >nul 2>&1
if errorlevel 1 (
  echo Installing Python dependencies...
  py -3 -m pip install -r requirements.txt
  if errorlevel 1 (
    echo ERROR: Install failed. Check Python installation and Internet access.
    pause
    exit /b 1
  )
)
py -3 -m biosphere view
if errorlevel 1 echo Viewer exited with an error.
pause
