# The Accidental Biosphere

**A runnable artificial-life research prototype, not a scripted animal game.**

The system creates an ecological world of digital organisms. Each organism has a tiny **16-weight inherited motor controller**. It senses food availability ahead, to its left and right, its own stored energy, and nearby crowding; its controller produces two outputs: *turn* and *speed*. The program does **not** contain an `if food_on_left: turn_left` rule. Movement policies can spread only if organisms carrying those policies leave more surviving descendants. Organisms automatically collect available food where they stand; above an energy threshold, they automatically reproduce with a mutating copy of their controller.

The separate simulation engine runs without a graphics window, and the optional Pygame viewer makes the same agents visible. Files include automated tests, full deterministic checkpoints, reproduction lineage events, and repeated experiments.

**v0.4 update (Experiment 004):** Sparse separated food islands, intensified movement costs, an isolated-target assay and speed-clamped steering controls. **First evidence that turning itself can help in a sparse ecology:** normal island-trained controllers harvested 0.3485 versus 0.2792 with zero turning, a difference reproduced across all 8 training seeds. At identical externally fixed speed 0.60 the effect remained (0.3428 vs 0.2862). But controllers with steering disabled *reached central resource cores more often*, so purposeful food-directed navigation is **not established**. Eight new training seeds × 3 ecologies = **24 saved evolved populations**. Full data and the separately labeled post-hoc mechanism study: [`docs/EXPERIMENT_004.md`](docs/EXPERIMENT_004.md).

**v0.4 update (Experiment 004):** Added narrow, spatially separated food islands; higher movement costs; a matched direct target-reach assay; and follow-up steering controls at **fixed speed**. Eight new independent seeds (701–708) were trained in three habitats (**24 evolved populations**). With movement speed held to 0.60, evolved island-agent steering harvested **0.3428 vs 0.2862** without turning in island common gardens, positive in all eight seeds; but zero-turn agents entered target cores more often in a separate assay. Thus turning has **measurable utility for sparse-ecosystem harvesting, not demonstrated precise target-directed navigation**. Methods, results and limitations: [`docs/EXPERIMENT_004.md`](docs/EXPERIMENT_004.md).

**v0.3 update (Experiment 003):** New reflecting walls, seeded relocation of stocked food patches, high motion-cost environments, and viewer toggles. Eight fresh seeds × four training ecologies = **32 evolved populations**, evaluated in four matched novel environments with steering ablations. Moving-patch-trained controllers generalized well, but suppressing steering still improved harvest: **a successful food-navigation strategy has not emerged**. Full method/data: [`docs/EXPERIMENT_003.md`](docs/EXPERIMENT_003.md).

**v0.2 update (Experiment 002):** 18 *new* training seeds replicated a harvesting improvement, then motor ablations showed that **turning off steering actually increases harvesting** in this ecosystem. The strongest established adaptation is currently faster, more effective locomotion, not intelligent navigation. Lowering food regrowth also produced an observable extinction boundary. See [`docs/EXPERIMENT_002.md`](docs/EXPERIMENT_002.md), including surprising negative results and methodological limits.

## Start on Windows

1. Install **Python 3.10 or later** with Python added to PATH (the Windows Python launcher `py` is also supported).
2. Extract the entire ZIP. Double-click **`run_windows.bat`** to install dependencies if needed and launch the Pygame microscope.
3. Or, open a terminal *inside this project folder* and run:

```powershell
py -3 -m pip install -r requirements.txt
py -3 -m biosphere view
```

This ZIP is **Python source code**, not a precompiled `.exe`. Pygame is installed on your own PC when you run the script.

### Viewer controls

- **Space** — pause/unpause simulation
- **+ / -** — double/halve simulation steps per rendered frame
- **Click an organism** — inspect its parent ID, generation, age, energy
- **F** — switch between food remaining and land carrying capacity
- **[ / ]** — decrease/increase food replenishment rate live
- **B** — switch between wraparound edges and reflecting walls
- **I** — toggle original hills versus sparse resource islands (restarts from the same founder seed and selected settings)
- **M** — toggle food-patch relocation every 35 ticks (stocks move with capacity)
- **C** — toggle normal/high motion-energy cost
- **I** — toggle resource terrain between normal hills and isolated food islands (**restarts population** with original seed)
- **R** — restart the original founding seed using the **currently selected** environment settings
- **H** — explanatory overlay
- **S** — save full checkpoint plus screenshot to `results/viewer/`
- **Esc** — exit

Screenshots are visual records; `world_*.npz` checkpoints contain the **full simulation**, including food, individual organisms, genomes and RNG state.

## Headless mode and experiments

Headless mode only requires NumPy (`pip install numpy`), and runs without Pygame.

```powershell
py -3 -m biosphere run --seed 5 --steps 3000 --events --output results/my_world
py -3 -m biosphere run --resume results/my_world/world.npz --steps 1000 --output results/continued
py -3 -m biosphere experiment --seeds 6 --steps 1200 --probe-ticks 180 --output results/my_experiment
py -3 -m biosphere investigate --seed-start 101 --seeds 18 --steps 1200 --probe-ticks 240 --output results/my_investigation
py -3 -m biosphere environment --seed-start 401 --seeds 8 --steps 900 --probe-ticks 160 --count 160 --output results/my_environment
py -3 -m biosphere run --seed 5 --steps 1000 --boundary-mode reflect --patch-shift-interval 35 --move-cost 0.75 --output results/my_hard_world
py -3 -m biosphere navigation --seed-start 701 --seeds 8 --steps 1000 --probe-ticks 180 --count 120 --output results/experiment_004
py -3 -m biosphere isolate --seed-start 701 --seeds 8 --count 120 --probe-ticks 180 --trained-results results/experiment_004 --output results/experiment_004
py -3 -m biosphere view --resource-layout islands --move-cost 0.20  # uses background 0.01
py -3 -m biosphere navigation --seed-start 701 --seeds 8 --steps 1000 --probe-ticks 180 --count 120 --output results/experiment_004
py -3 -m biosphere isolate --seed-start 701 --seeds 8 --count 120 --probe-ticks 180 --trained-results results/experiment_004 --output results/experiment_004
py -3 -m pytest -q
```

**The checked-in experiment** is already in `results/experiment_6seed/` and includes:

| File | What it is |
| --- | --- |
| `summary.json` | Treatment means, paired differences, bootstrap intervals |
| `probe_trials.csv` | Every treatment result for all 6 seeds |
| `training_history.csv` | Time-series populations and genomes stats |
| `common_garden.png` | Raw replicate outcomes and treatment means |
| `population_dynamics.png` | Training populations, mutation vs no mutation |
| `evolved_seed_1.npz` ... `evolved_seed_6.npz` | Resumable evolved worlds, full state |

`results/lineage_demo/lineage.csv` also contains birth and death events with organism IDs, parent IDs and generations. `results/ecosystem_snapshot.png` is an actual rendering of evolved seed 1, step 1200. The snapshot is **not** a test of the Pygame window itself.

### Experiment 002 files

`results/experiment_002/` includes `summary.json`, independent-seed outcomes in `training_outcomes.csv`, head-to-head interventions in `probe_trials.csv`, controlled cue-response measurements in `controller_responses.csv`, interpretable effective motor weights in `effective_genes.csv`, figures, and **36 restorable evolved worlds** from two selected regrowth conditions. This second experiment used new training seeds **101–118** and five levels of food regrowth.

The main result is a challenge to a simplistic interpretation: evolving stronger responses to side-specific food cues is **not** equivalent to evolving superior navigation. In these novel-test gardens, fixed zero-turn agents harvested more food than normally turning evolved agents. That result is described and tested in detail in `docs/EXPERIMENT_002.md`.

### Experiment 003 files

`results/experiment_003/` contains `summary.json` and all seed-level outcomes, an ecology-to-ecology transfer heatmap, the performance difference from disabling turning in four environments, controller speed plots, **32 saved trained checkpoints** (8 seeds × 4 ecologies), and real snapshot images. Details and cautious interpretation: [`docs/EXPERIMENT_003.md`](docs/EXPERIMENT_003.md).

The no-hardcoded-navigation constraint is preserved in the engine. The new environment options are independent of the genome and can be switched in the viewer or set via the CLI.

### Experiment 004 files

`results/experiment_004/` contains all independent outcomes, eight-seed paired contrasts, two follow-up fixed-speed CSVs, figures including `fixed_speed_harvest.png` and `fixed_speed_target_hits.png`, **24 full-state evolved checkpoints**, and individual seed caches for replay. The complete methods, outcomes, caveats and reproducibility commands are in [`docs/EXPERIMENT_004.md`](docs/EXPERIMENT_004.md). The viewer can recreate island terrain with **I** (restart) or use `python -m biosphere view --resource-layout islands --move-cost 0.50`.


### Experiment 004 files

`results/experiment_004/` contains reproducible ecology-to-ecology transfer data, individual-seed held-out motor ablations, the 36-target acquisition assay, a separate **fixed-speed motor isolation** check, three figures, and all **24 evolved-world checkpoints**. `seed_parts/` permits exact restart of interrupted replicated experiments without adding partial seeds. See [`docs/EXPERIMENT_004.md`](docs/EXPERIMENT_004.md) for results and limitations.

## First observed result

In a **six-seed exploratory experiment**, evaluating each group in fresh environments with otherwise matched conditions:

- Founder mean harvest: **0.4621** food units / starting organism / step.
- Evolved mean harvest: **0.5873** (+27.1% over founders).
- Evolved with external senses removed: **0.5244** (worse than evolved unblinded).
- Founder with external senses removed: **0.4277**.
- Evolved without new mutations: **0.5921**, statistically too close on these six seeds to conclude that mutation helped or hurt.
- Mean movement speed increased from **0.488** (founders) to **0.713** (evolved), suggesting selection favored greater movement in this ecology.
- Difference in external-sensor benefit between evolved and founders: **+0.0286** units / organism / tick (paired bootstrap 95% interval **[0.0167, 0.0398]**).

This is evidence for improved, heritable **sensorimotor resource harvesting**, with an increased benefit from external sensing. It does **not** demonstrate animal intelligence or evolved cooperation. The simulation was prototyped and tuned before this evaluation; all numbers here are **exploratory**, not a preregistered finding. See `docs/EXPERIMENT_001.md` for experimental design, limitations and uncertainty.

## Under the hood

- World: **72 × 54 spatial grid** with selectable toroidal wrap or specular reflecting boundaries, randomized smooth food hills **or eight separated resource islands**, local depletion and regrowth, and optional patch relocation.
- Brain: **2 motor neurons × 8 input channels**, randomized at foundation, cloned to offspring with independent parameter mutations.
- Life cycle: stored energy, fuel expenditure for existence and motion, automatic harvesting, energy-costly asexual reproduction, finite life and starvation.
- Ecology: offspring begin close to parent, compete for food, and inherit the parent's controller. There is no artificial rescuer if all organisms die.
- Population cap: default **900** simultaneous organisms.
- Logging: genome variance, population, deaths, births, lineage depth, resource stock, harvesting, movement, and controller response.
- Reproducibility: NumPy PRNG seed recorded in checkpoint, together with its internal state; restart is bitwise tested.

**No behavior is guaranteed to emerge.** The world is deliberately simple and constrained. Organisms cannot currently communicate, attack, form families, learn during life, develop new body plans, or create complex social systems. Results do not demonstrate open-ended Darwinian innovation.

## Documentation

- `docs/RESEARCH.md`: literature review and source provenance (Tierra, Avida, Polyworld).
- `docs/MODEL.md`: formal rules, input/output semantics and engineering tradeoffs.
- `docs/EXPERIMENT_001.md`: hypothesis, design, data, results, limitations, further tests.
- `docs/EXPERIMENT_002.md`: motor ablation, controller-weight, scarcity and extinction tests.
- `docs/EXPERIMENT_003.md`: wrap versus walls, shifting habitat, high motion cost, generalization and steering ablations.
- `docs/EXPERIMENT_004.md`: sparse islands, causally useful steering, failed navigation predictions, fixed-speed interventions.
- `docs/JOURNAL.md`: dated research log of observations, failures and changes.
- `docs/QA.md`: automated tests and verification status.

## Optional experiment re-render

From the project folder:

```powershell
py -3 experiments/plot_snapshot.py results/experiment_6seed/evolved_seed_1.npz results/new_snapshot.png
```

You may run the original checkpoint for many more generations and save the result. Do not confuse tick count with generational count: generations are calculated from parent-child lineage, and many overlapping generations coexist.

## Project layout

```text
biosphere/                 Source: engine, CLI, viewer, experiments
experiments/               Snapshot rendering utility
tests/                     Reproducible automated correctness tests
docs/                      Research, methods, journal, QA
results/                   Real simulation output and controls
run_windows.bat            Windows start shortcut
requirements.txt           Python dependencies
pyproject.toml             Installable Python project
```

License: this prototype's new source code is offered under the MIT License in `LICENSE`. Research references are **not** included as redistributed third-party source code.

## Interpretation warning for v0.4

Sparse islands are the first tested setting where turning **contributes positively to harvested food** under both natural and experimentally fixed speed. This still does **not** demonstrate precise navigation to patch centers, because straight-line agents enter isolated target cores more often than steering ones. Do not call these organisms intelligent navigators. The post-hoc fixed-speed analysis and its limitations are reported separately from the original tests.

## Interpretation warning for v0.3

The mechanism tests corrected an intuitive but unsupported story. Agents became better at harvesting food in aggregate, but **zeroing their steering increased harvest even in the new non-toroidal and moving-patch worlds**; the system does not yet exhibit effective directional foraging as a learned strategy. Moving-patch genomes performed broadly better, which is a generalizing adaptive phenotype, not a demonstrated new species, intelligence or sophisticated foraging. All experiments are exploratory.
