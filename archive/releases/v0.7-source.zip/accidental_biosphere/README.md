# The Accidental Biosphere — v0.7

**An evolving digital ecosystem you can observe, inspect, and experiment with.** This is a research-first artificial-life prototype with a growing interactive Pygame observatory. Its inhabitants are not scripted animals or proven intelligent beings.

Organisms inherit 16 motor-controller weights (two outputs × eight sensory inputs), experience energy costs, harvest local renewable food, reproduce with mutation, age and die. Whether an organism turns or travels quickly is determined by its inherited controller, not a programmed command to seek food. All experiments run headlessly with deterministic seeds and checkpoint replay.

## Quick start on Windows

1. Install **Python 3.10+**. If possible, select **Add Python to PATH**.
2. Extract the complete downloaded ZIP to a writable folder.
3. Double-click **`run_windows.bat`** to install the required Python packages and open the viewer. It supports both `py -3` and `python` launchers.

Alternatively, in a command prompt inside the extracted folder:

```powershell
python -m pip install -r requirements.txt
python -m biosphere view
```

To watch an actual evolved sparse-world population instead of starting with random founders:

```powershell
python -m biosphere view --resume results/experiment_004/checkpoints/seed_701_islands.npz
```

**Note:** This is Python source, not a compiled Windows `.exe`. This environment could not install Pygame, so the graphical window remains unverified. The inherited `observatory_visual_preview.png` is a v0.5 Pillow-generated design preview using real simulation data, **not** a current Pygame screenshot.

## New in v0.7: The Living Observatory

The observatory is now slower and more legible by default: **10 simulation ticks per real second**, with independent render pacing and single-stepping. Birth and death map markers last 4.5 actual seconds. Select a specimen to track its real life; enable automatic pause on selected offspring/death events (`P`). The selected organism remains inspectable after death rather than disappearing.

**Saved individual histories** now include birth/death tick, direct offspring, first feeding, first reproduction, lifetime harvested food, distance moved, peak energy, and cause of death. Select an individual to start sampling its real path and energy (up to 240 samples per tracked individual). These details are preserved when the world is saved. A paginated, scrollable archive of extinct organisms (`A`), clickable family graph (`Y`) and microscope (`O`) make the evolving population easier to understand. Microscope values come from the actual 16 inherited neural weights and eight sensory inputs, not scripted personalities.

Action controls are two rows instead of squeezed into one; sidebar tabs always expose the latest real events, specimen details or family connections. Press `R` or `I` **twice** within six seconds to confirm a destructive restart. `S` saves a checkpoint and screenshot. The GUI needs graphical runtime QA; see [`docs/GRAPHICAL_QA_v0.7.md`](docs/GRAPHICAL_QA_v0.7.md).

### New controls

| Control | Meaning |
| --- | --- |
| `A` / `Y` | Browse extinct archive (scroll / Page Up–Down) / open family tree |
| `O` | Inspect live sensor values and inherited neural weights |
| `P` | Toggle pause when selected specimen dies or reproduces |
| `U` / `K` | Select the specimen's parent / latest direct child |
| `V` / `G` / `Tab` | Sidebar: Events / Lineage / Specimen |
| `R` twice / `I` twice | Confirm new original-seed world / switch habitat and reset |
| `Space` / `N` / `+` / `-` | Pause / step / speed up / slow down (ticks per real second) |
| `S` / `L` / mouse wheel | Save / follow specimen / zoom |
| `F` / `T` | Food heatmap toggle / sandbox food brush |
| `H` / `J` | Help / field notebook |

Real ecological milestones (first birth, fifth generation, starvation, old age, carrying-capacity cap, extinction) are logged when they actually occur. These records contain no invented personalities, speech or objectives.

**Historical checkpoint limitation:** checkpoint versions before v0.7 did not record lifetime metadata, so archived dead individuals and their detailed ancestral histories cannot be reconstructed from those files. Live organisms are assigned approximate birth ticks from their saved ages; new history is captured from the resume point onward.

### Experiment 007: reproductive consequences of sensing food

The new `fitness` command reuses the archived Experiment 004 genomes and lets organisms eat, reproduce, die and compete over 350 ticks while selectively removing or mirroring food-sensor inputs. Eight training seeds × two genome groups × two speed conditions × three sensory conditions = **96 matched ecological colony trials**. In expensive-island-trained populations, enabling their normal food cues produced **0.800 direct children per original founder**, versus **0.378 with the food inputs removed** (natural motor speed; the difference was positive in all eight independently trained seeds). With speed fixed to 0.60 the means were 0.817 versus 0.442. Final population did *not* show a comparably consistent advantage. This supports a reproductive effect of the inherited cue responses under test conditions, **not intelligence or reliable target-directed navigation**.

See [complete Experiment 007 methods and caveats](docs/EXPERIMENT_007.md), the raw [`results/experiment_007/trials.csv`](results/experiment_007/trials.csv) and [`RELEASE_NOTES_v0.7.md`](RELEASE_NOTES_v0.7.md).

```powershell
python -m biosphere fitness --seed-start 701 --seeds 8 --trained-results results/experiment_004 --output results/my_fitness_replay
python experiments/plot_fitness.py
```

### Optional actual graphical smoke test (requires installed Pygame)

```powershell
python -m biosphere view --smoke-frames 120 --screenshot results/viewer/qa.png --qa-report results/viewer/qa.json
```

This produces a real SDL/Pygame screenshot and a frame-time summary when run in a working graphical environment; **such a window was not available for verification in the authoring container**.

---

## Earlier viewer features (retained from v0.6)

- Follow actual organisms as they move; inspect parent ID, generation, age, energy, food intake and live speed/turn commands.
- Watch birth and death markers, a population sparkline, small event feed, and a six-observation field journal.
- Pan, zoom, pause, step through time or run much faster. Compare food-stock and capacity heatmaps.
- Restart the original seed with different wall, island, patch-shift, resource growth and movement-cost settings.
- Toggle the **SANDBOX FEED BRUSH** to expand food patches with the mouse. Edits are recorded and visibly tagged **INTERVENED — not a control run**; they are never included in reproducible research commands. Live environment changes are logged and marked as interventions too; a restart with selected settings clears this label.
- Save the full simulation and a screenshot in `results/viewer/` with microsecond-unique filenames.

### Viewer controls

| Input | Effect |
| --- | --- |
| **Left click** | Select nearest nearby organism / use clickable action bar |
| **Mouse wheel** or `Z` / `X` | Zoom in / out |
| **Right-drag** | Pan camera (stops following the current specimen) |
| `L` | Follow or stop following selected organism |
| `Space` / `N` | Pause or resume / single-step (also pauses) |
| `+` / `-` | Faster / slower, from 0.25 to 25 ticks per frame |
| `F` | Food remaining / carrying-capacity heatmap |
| `T` | Toggle sandbox nutrient brush; click ground to fertilize |
| `J` / `H` | Field journal / help overlay |
| `I` / `R` | Switch hills ↔ islands and restart / restart same seed and settings |
| `B` / `M` / `C` | Reflecting or wrap boundaries / moving food patches / motion energy cost |
| `[` / `]` | Lower / raise resource regrowth while world is running |
| `S` / `Esc` | Save checkpoint and screenshot / exit |

Primary controls also have clickable toolbar buttons. The viewer now starts at 10 simulation ticks per wall-clock second; older frame-based pacing was replaced in v0.7.

## Experiment 006: is turning actually food-contingent?

**New in v0.6:** a controlled trajectory laboratory, not a scripted AI behavior or a new Pygame interface. It reuses the original 16-weight controllers and archived seed-701–708 evolutionary populations in motor-only experiments. Food/energy feedback is suppressed and speed is held constant to expose the effects of sensory cues themselves.

- **384 matched trials:** 8 training seeds × 4 genome groups × 2 start conditions × 6 cue/motor interventions; 36 controllers per trial, 90 steps each.
- **Near-patch search:** expensive-island-trained controllers entered any core in 37.2% of probes with accurate cues, 9.4% with absent cues, and 9.7% with displaced cues. Straight movers reached a core 85.8% of the time.
- **Core residence:** the same evolved controllers spent 75.4% of their time inside a core with accurate cues and 79.0% with barren cues. Circling persists without resource information.
- **Evolutionary comparison:** the accurate-cue search benefit exceeded that of founders by 15.3 percentage points (7/8 seeds positive; exploratory descriptive interval 7.6–22.2 points).
- Actual positions/angles, core overlap, cue-dependent turn responses and seed-level contrasts are saved. Hypothetical resource exposure is *not* reported as actual food harvested.

Read [Experiment 006](docs/EXPERIMENT_006.md) and [v0.6 release notes](RELEASE_NOTES_v0.6.md). Run:

```powershell
python -m biosphere trajectory --seed-start 701 --seeds 8 --ticks 90 --trained-results results/experiment_004 --output results/my_trajectory_replay
python experiments/plot_trajectory.py
```

The visual plot script reads the included canonical `results/experiment_006` data by default. The new experimental study is **headless**, while the familiar interactive Pygame viewer continues to work from the unchanged `view` command if Pygame is installed.

## Experiment 005: find a food patch or remain in one?

The v0.4 studies found that removing steering improved direct target encounters but steering improved resource collection once food was available. v0.5 separates **search** from **residency** with two matched assays.

- **256 experimental trials:** eight independent training seeds × four genome groups × two starting conditions × four motor interventions.
- Each trial tracks 36 organisms, all at externally fixed forward speed 0.60, for 75 ticks, without reproduction or mutation.
- Costly-island-trained organisms entered a food core from a distant start in **33.7%** of normal-controller cases versus **74.3%** with steering disabled.
- When they began inside a core, normal controllers spent **80.9%** of the assay inside a core, versus **14.7%** with steering disabled. Their average intake was **1.351** versus **0.543** food units/organism/tick.
- Critically, removing food sensors did **not** abolish local residency: **83.0%** occupancy in food-blind controllers. **Persistent turning may be responsible, not deliberate food-seeking.**

See [`docs/EXPERIMENT_005.md`](docs/EXPERIMENT_005.md) for complete procedure, seed-paired contrasts, caveats and limitations. This was an **exploratory analysis of existing evolved checkpoints**, not independently preregistered evidence of intelligence or planning.

### Reproduce Experiment 005

```powershell
python -m biosphere residency --seed-start 701 --seeds 8 --ticks 75 --trained-results results/experiment_004 --output results/my_residency_replay
python experiments/plot_residency.py
python -m pytest -q
```

The `trials.csv` and `summary.json` in `results/experiment_005/` are the raw and aggregate evidence. Precomputed charts are `search_arrival.png`, `core_residency.png`, `resident_harvest.png` and `sensory_ablations.png`.

## Other command-line workflows

```powershell
python -m biosphere run --seed 5 --steps 3000 --events --output results/my_world
python -m biosphere run --resume results/my_world/world.npz --steps 1000 --output results/continued
python -m biosphere navigation --seed-start 701 --seeds 8 --steps 1000 --probe-ticks 180 --count 120 --output results/my_navigation
python -m biosphere isolate --seed-start 701 --seeds 8 --count 120 --probe-ticks 180 --trained-results results/experiment_004 --output results/my_isolation
```

Older experiments also have the subcommands `experiment`, `investigate`, and `environment`. Run `python -m biosphere --help` for all commands and `python -m biosphere view --help` for viewer options. Every run can be resumed through a `.npz` checkpoint; the full NumPy generator state is included and `allow_pickle=False` is used during loading.

## Visual/game-design audit, science and QA

- [`docs/VISUAL_AUDIT.md`](docs/VISUAL_AUDIT.md): actual v0.4 visual/code audit, changes in v0.5, and what remains unverified.
- [`docs/EXPERIMENT_001.md`](docs/EXPERIMENT_001.md) to [`docs/EXPERIMENT_006.md`](docs/EXPERIMENT_006.md): successive experimental findings, successful and failed predictions.
- [`docs/MODEL.md`](docs/MODEL.md): world state, sensing, motor outputs, energy transfer, reproduction.
- [`docs/RESEARCH.md`](docs/RESEARCH.md): precedent and citation list for Tierra, Avida and Polyworld.
- [`docs/JOURNAL.md`](docs/JOURNAL.md): ongoing research log.
- [`docs/QA.md`](docs/QA.md): test coverage, scientific reproducibility and graphical limitations.

**Limitations:** This system cannot currently learn within a lifetime, invent anatomy, communicate, have offspring-care behavior, create social structures, or reliably orient toward a distant target. It is more engaging as a microscope than v0.4, but it is not yet a complete strategy game. Graphical UX needs independent test coverage on an actual desktop with Pygame.

License: MIT, see `LICENSE`. Third-party literature and software were referenced, not incorporated as source code.
