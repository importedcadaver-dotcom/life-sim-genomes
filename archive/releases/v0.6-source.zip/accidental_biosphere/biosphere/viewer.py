"""Interactive ecosystem observatory. Visuals never alter evolutionary rules.

Pygame is imported lazily so the research engine and geometry tests remain
headless. The only terrain mutation is the explicitly marked sandbox brush.
"""
from __future__ import annotations

from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
import math

import numpy as np

from .simulation import Config, World


@dataclass(frozen=True)
class ViewLayout:
    map_rect: tuple[int, int, int, int]
    side_rect: tuple[int, int, int, int]
    toolbar_y: int
    pixel_scale: float


def layout_for(width: int, height: int, world_width: int = 72,
               world_height: int = 54) -> ViewLayout:
    """Responsively fit the entire habitat and reserve a real HUD region."""
    sidebar = min(355, max(275, int(width * .275)))
    available_w = max(160, width - sidebar - 64)
    available_h = max(120, height - 178)
    scale = min(available_w / world_width, available_h / world_height)
    pw, ph = max(1, int(world_width * scale)), max(1, int(world_height * scale))
    x = max(15, int((width - sidebar - pw) / 2))
    y = 106 + max(0, (available_h - ph) // 2)
    return ViewLayout((x, y, pw, ph), (width - sidebar - 18, 103, sidebar, height - 174),
                      height - 57, scale)


def terrain_rgb(food: np.ndarray, capacity: np.ndarray, *, show_food: bool = True) -> np.ndarray:
    """Smooth, high-contrast scientific heatmap; no simulated 3D or fake entities."""
    values = food if show_food else capacity
    density = np.clip(np.log1p(values) / np.log1p(11), 0, 1)
    anchors = np.array([[14, 27, 35], [24, 68, 67], [49, 116, 92],
                        [147, 184, 103], [250, 218, 128]], dtype=float)
    u = density * (len(anchors) - 1)
    i = np.minimum(u.astype(int), len(anchors) - 2)
    fractional = (u - i)[..., None]
    return np.uint8(np.clip(anchors[i] * (1 - fractional) + anchors[i + 1] * fractional, 0, 255))


def toggle_resource_layout(cfg: Config) -> Config:
    if cfg.resource_layout == "hills":
        return replace(cfg, resource_layout="islands", resource_background=0.01)
    return replace(cfg, resource_layout="hills", resource_background=0.25)


def view(args) -> None:
    try:
        import pygame
    except ImportError as exc:
        raise SystemExit("Install the optional viewer: pip install pygame-ce") from exc

    pygame.init()
    screen = pygame.display.set_mode((1400, 880), pygame.RESIZABLE)
    pygame.display.set_caption("Accidental Biosphere | Field Observatory")
    clock = pygame.time.Clock()
    ui = pygame.font.SysFont("segoeui", 17)
    small = pygame.font.SysFont("segoeui", 14)
    big = pygame.font.SysFont("segoeui", 26, bold=True)
    num = pygame.font.SysFont("consolas", 23, bold=True)
    micro = pygame.font.SysFont("consolas", 12)
    BG, PANEL, PANEL2 = (10, 18, 24), (20, 33, 40), (28, 45, 50)
    TEXT, MUTED, GREEN, GOLD, CORAL = ((233, 239, 232), (151, 169, 172),
                                      (144, 224, 167), (247, 205, 116), (241, 130, 112))
    world = (World.load(args.resume) if args.resume else World(
        Config(max_population=args.max_population, boundary_mode=args.boundary_mode,
               patch_shift_interval=args.patch_shift_interval, move_cost=args.move_cost,
               resource_layout=args.resource_layout,
               resource_background=(args.resource_background if args.resource_background is not None else
                                    (0.01 if args.resource_layout == "islands" else 0.25)),
               island_count=args.island_count, island_sigma=args.island_sigma,
               island_peak=args.island_peak), seed=args.seed))
    seed = world.seed
    pause = False
    pacing = [0.25, 0.5, 1, 2, 4, 10, 25]
    pace_index = 2
    sim_fraction = 0.0
    selected_id: int | None = None
    follow = False
    zoom_steps = (1.0, 1.5, 2.25, 3.5)
    zoom_index = 0
    cam_x, cam_y = world.config.width / 2, world.config.height / 2
    show_food = True
    show_help = False
    show_journal = False
    sandbox_brush = False
    event_rings: list[tuple[int, str, float, float]] = []
    selected_path: list[tuple[float, float]] = []
    event_feed: list[tuple[int, str]] = []
    history: list[tuple[int, int, float]] = [(world.tick, world.population, 0.0)]
    buttons: list[tuple[pygame.Rect, str]] = []
    notice, notice_until = "", 0
    frame = 0
    pending_save = False
    saving_path: Path | None = None
    dragging = False
    drag_origin = None
    drag_camera = None
    regrowth_presets = (0.001, 0.003, 0.006, 0.012, 0.030)

    def announce(message: str) -> None:
        nonlocal notice, notice_until
        notice = message
        notice_until = frame + 150

    def caption(t: str, x: float, y: float, color=MUTED, font=small,
                max_width: int | None = None) -> None:
        text = str(t)
        if max_width is not None and font.size(text)[0] > max_width:
            while text and font.size(text + "...")[0] > max_width:
                text = text[:-1]
            text += "..." if text else ""
        screen.blit(font.render(text, True, color), (int(x), int(y)))

    def box(rect: pygame.Rect, color=PANEL, radius=12, border=None):
        pygame.draw.rect(screen, color, rect, border_radius=radius)
        if border:
            pygame.draw.rect(screen, border, rect, 1, border_radius=radius)

    def reset_world() -> None:
        nonlocal world, selected_id, follow, cam_x, cam_y, sim_fraction, pause
        world = World(world.config, seed=seed)
        selected_id = None
        follow = False
        cam_x, cam_y = world.config.width / 2, world.config.height / 2
        sim_fraction = 0.0
        pause = False
        event_rings.clear()
        event_feed.clear()
        history.clear()
        selected_path.clear()
        history.append((world.tick, world.population, 0.0))

    def zoom(change: int) -> None:
        nonlocal zoom_index
        zoom_index = max(0, min(len(zoom_steps) - 1, zoom_index + change))

    def intervene_config(**updates) -> None:
        """Log live environment changes so a save cannot masquerade as a control."""
        old_values = {k: getattr(world.config, k) for k in updates}
        world.config = replace(world.config, **updates)
        world.manual_interventions.append({
            "tick": world.tick, "kind": "live_environment_change",
            "before": old_values, "after": updates})
        announce("Live ecology changed: this run is now marked as intervened")

    def operate(action: str) -> None:
        nonlocal pause, pace_index, sim_fraction, show_food, show_help, show_journal
        nonlocal sandbox_brush, pending_save, selected_id, follow
        if action == "pause":
            pause = not pause
        elif action == "step":
            pause = True
            advance(1)
        elif action == "faster":
            pace_index = min(len(pacing) - 1, pace_index + 1)
        elif action == "slower":
            pace_index = max(0, pace_index - 1)
        elif action == "zoom_in":
            zoom(1)
        elif action == "zoom_out":
            zoom(-1)
        elif action == "map":
            show_food = not show_food
        elif action == "follow":
            follow = bool(selected_id is not None and not follow)
            if selected_id is None:
                announce("Choose an organism before following it")
        elif action == "sandbox":
            sandbox_brush = not sandbox_brush
            announce("Sandbox brush enabled: click terrain to grow food" if sandbox_brush else
                     "Sandbox brush disabled: click organisms to inspect")
        elif action == "save":
            pending_save = True
        elif action == "help":
            show_help = not show_help
        elif action == "journal":
            show_journal = not show_journal
        elif action == "restart":
            reset_world()
            announce("Same seed and active environment, restarted")
        elif action == "layout":
            world.config = toggle_resource_layout(world.config)
            reset_world()
            announce("New terrain: original founder seed, no carried-over organisms")
        elif action == "walls":
            intervene_config(boundary_mode=(
                "reflect" if world.config.boundary_mode == "wrap" else "wrap"))
            announce("Boundary mode: " + world.config.boundary_mode)
        elif action == "shift":
            intervene_config(patch_shift_interval=(
                0 if world.config.patch_shift_interval else 35))
        elif action == "cost":
            intervene_config(move_cost=(
                .065 if world.config.move_cost > .065 else .75))
        elif action in ("less_growth", "more_growth"):
            current = min(range(len(regrowth_presets)),
                          key=lambda i: abs(regrowth_presets[i] - world.config.growth_rate))
            current = max(0, min(len(regrowth_presets) - 1,
                                 current + (-1 if action == "less_growth" else 1)))
            intervene_config(growth_rate=regrowth_presets[current])

    def advance(ticks: int) -> None:
        nonlocal selected_id, follow
        for _ in range(ticks):
            if not world.population:
                break
            before = world.population
            world.step()
            births = sum(ev["kind"] == "birth" for ev in world.last_events)
            deaths = before + births - world.population
            if births or deaths:
                for kind in ("birth", "death"):
                    for ev in [e for e in world.last_events if e["kind"] == kind][:8]:
                        if "x" in ev:
                            event_rings.append((world.tick, ev["kind"], ev["x"], ev["y"]))
                if selected_id is not None:
                    offspring = sum(e["kind"] == "birth" and e.get("parent_id") == selected_id
                                    for e in world.last_events)
                    if offspring:
                        event_feed.append((world.tick, f"Specimen #{selected_id} produced {offspring} offspring"))
                event_feed.append((world.tick, f"{births:+d} births  /  {deaths} deaths"))
                event_feed[:] = event_feed[-8:]
            if world.tick % 8 == 0:
                history.append((world.tick, world.population, world.last_mean_intake))
                history[:] = history[-200:]
            if selected_id is not None:
                living = np.flatnonzero(world.ids == selected_id)
                if len(living):
                    j = int(living[0])
                    selected_path.append((float(world.x[j]), float(world.y[j])))
                    selected_path[:] = selected_path[-90:]
            if selected_id is not None and not np.any(world.ids == selected_id):
                event_feed.append((world.tick, f"Specimen #{selected_id} died"))
                event_feed[:] = event_feed[-8:]
                selected_id, follow = None, False
                selected_path.clear()
            if world.population == 0:
                event_feed.append((world.tick, "Population extinct — no automatic rescue"))
        event_rings[:] = [e for e in event_rings if world.tick - e[0] <= 22][-220:]

    def map_to_screen(x: float, y: float, ox: int, oy: int, pw: int, ph: int,
                      units: float) -> tuple[int, int]:
        dx, dy = x - cam_x, y - cam_y
        if world.config.boundary_mode == "wrap":
            dx = (dx + world.config.width / 2) % world.config.width - world.config.width / 2
            dy = (dy + world.config.height / 2) % world.config.height - world.config.height / 2
        return int(ox + pw / 2 + dx * units), int(oy + ph / 2 + dy * units)

    def screen_to_map(sx: float, sy: float, ox: int, oy: int, pw: int, ph: int,
                      units: float) -> tuple[float, float]:
        px = cam_x + (sx - ox - pw / 2) / units
        py = cam_y + (sy - oy - ph / 2) / units
        if world.config.boundary_mode == "wrap":
            return px % world.config.width, py % world.config.height
        return max(0.0, min(world.config.width - 1e-6, px)), max(0.0, min(world.config.height - 1e-6, py))

    def button(rect: pygame.Rect, name: str, caption_text: str, active=False) -> None:
        mx, my = pygame.mouse.get_pos()
        over = rect.collidepoint(mx, my)
        color = (48, 81, 76) if active else ((43, 63, 68) if over else PANEL)
        box(rect, color, 8, (94, 150, 135) if active else None)
        surf = small.render(caption_text, True, GREEN if active else TEXT)
        screen.blit(surf, surf.get_rect(center=rect.center))
        buttons.append((rect, name))

    running = True
    while running:
        frame += 1
        w, h = screen.get_size()
        L = layout_for(w, h, world.config.width, world.config.height)
        ox, oy, pw, ph = L.map_rect
        sx, sy, sw, sh = L.side_rect
        units = L.pixel_scale * zoom_steps[zoom_index]
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif ev.type == pygame.VIDEORESIZE and (ev.w < 1020 or ev.h < 685):
                screen = pygame.display.set_mode((max(1020, ev.w), max(685, ev.h)), pygame.RESIZABLE)
            elif ev.type == pygame.KEYDOWN:
                keymap = {pygame.K_SPACE: "pause", pygame.K_n: "step", pygame.K_j: "journal",
                          pygame.K_EQUALS: "faster", pygame.K_KP_PLUS: "faster",
                          pygame.K_MINUS: "slower", pygame.K_KP_MINUS: "slower",
                          pygame.K_z: "zoom_in", pygame.K_x: "zoom_out",
                          pygame.K_f: "map", pygame.K_l: "follow", pygame.K_t: "sandbox",
                          pygame.K_s: "save", pygame.K_h: "help", pygame.K_r: "restart",
                          pygame.K_i: "layout", pygame.K_b: "walls", pygame.K_m: "shift",
                          pygame.K_c: "cost", pygame.K_LEFTBRACKET: "less_growth",
                          pygame.K_RIGHTBRACKET: "more_growth"}
                if ev.key == pygame.K_ESCAPE:
                    running = False
                elif ev.key in keymap:
                    operate(keymap[ev.key])
            elif ev.type == pygame.MOUSEWHEEL:
                zoom(1 if ev.y > 0 else -1)
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 3:
                if pygame.Rect(L.map_rect).collidepoint(ev.pos):
                    dragging, drag_origin, drag_camera = True, ev.pos, (cam_x, cam_y)
            elif ev.type == pygame.MOUSEBUTTONUP and ev.button == 3:
                dragging = False
            elif ev.type == pygame.MOUSEMOTION and dragging and drag_origin is not None:
                cam_x = drag_camera[0] - (ev.pos[0] - drag_origin[0]) / units
                cam_y = drag_camera[1] - (ev.pos[1] - drag_origin[1]) / units
                follow = False
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                hit = next((action for rect, action in buttons if rect.collidepoint(ev.pos)), None)
                if hit:
                    operate(hit)
                elif pygame.Rect(L.map_rect).collidepoint(ev.pos):
                    wx, wy = screen_to_map(*ev.pos, ox, oy, pw, ph, units)
                    if sandbox_brush:
                        amount = world.fertilize(wx, wy)
                        event_feed.append((world.tick, f"Sandbox nutrient bloom: +{amount:.0f} food capacity"))
                        event_feed[:] = event_feed[-8:]
                        announce("Sandbox modified: this world is no longer a control run")
                    elif world.population:
                        if world.config.boundary_mode == "wrap":
                            dx = np.abs(world.x - wx)
                            dy = np.abs(world.y - wy)
                            dx = np.minimum(dx, world.config.width - dx)
                            dy = np.minimum(dy, world.config.height - dy)
                        else:
                            dx, dy = np.abs(world.x - wx), np.abs(world.y - wy)
                        k = int(np.argmin(dx ** 2 + dy ** 2))
                        new_id = int(world.ids[k]) if (dx[k] ** 2 + dy[k] ** 2) ** .5 * units < 20 else None
                        if new_id != selected_id:
                            selected_path.clear()
                        selected_id = new_id
                        if selected_id is None:
                            follow = False

        if not pause and world.population:
            sim_fraction += pacing[pace_index]
            steps = min(int(sim_fraction), 25)
            sim_fraction -= steps
            if steps:
                advance(steps)
        if follow and selected_id is not None:
            where = np.flatnonzero(world.ids == selected_id)
            if len(where):
                cam_x, cam_y = float(world.x[where[0]]), float(world.y[where[0]])
        if world.config.boundary_mode == "reflect":
            halfx, halfy = pw / (2 * units), ph / (2 * units)
            cam_x = max(halfx, min(world.config.width - halfx, cam_x))
            cam_y = max(halfy, min(world.config.height - halfy, cam_y))
        else:
            cam_x %= world.config.width
            cam_y %= world.config.height

        screen.fill(BG)
        caption("THE ACCIDENTAL BIOSPHERE", 24, 17, TEXT, big)
        caption("FIELD OBSERVATORY   /   EXPERIMENTAL ARTIFICIAL LIFE", 25, 51, GREEN, micro)
        caption(f"SEED {seed}    |    {world.config.resource_layout.upper()}    |    "
                f"{world.config.boundary_mode.upper()} BOUNDARIES", w - 403, 24, MUTED, small, 370)
        pygame.draw.line(screen, (38, 61, 66), (24, 86), (w - 24, 86), 1)

        # Habitat map: a scientific food/capacity field, with creatures rendered on top.
        pygame.draw.rect(screen, (14, 27, 34), (ox - 2, oy - 2, pw + 4, ph + 4), border_radius=8)
        rgb = terrain_rgb(world.food, world.capacity, show_food=show_food)
        base = pygame.surfarray.make_surface(np.transpose(rgb, (1, 0, 2)))
        tile_w, tile_h = max(1, int(world.config.width * units)), max(1, int(world.config.height * units))
        surface = pygame.transform.smoothscale(base, (tile_w, tile_h))
        pygame.draw.rect(screen, (77, 110, 104), (ox - 2, oy - 2, pw + 4, ph + 4), 1, border_radius=8)
        screen.set_clip(pygame.Rect(ox, oy, pw, ph))
        left = ox + pw / 2 - cam_x * units
        top = oy + ph / 2 - cam_y * units
        shifts = (-1, 0, 1) if world.config.boundary_mode == "wrap" else (0,)
        for tx in shifts:
            for ty in shifts:
                xx, yy = int(left + tx * tile_w), int(top + ty * tile_h)
                if xx < ox + pw and xx + tile_w > ox and yy < oy + ph and yy + tile_h > oy:
                    screen.blit(surface, (xx, yy))
        # Native event markers are genuinely tied to births/deaths from World.step.
        for tick, kind, cx, cy in event_rings:
            px, py = map_to_screen(cx, cy, ox, oy, pw, ph, units)
            if ox <= px <= ox + pw and oy <= py <= oy + ph:
                age = world.tick - tick
                r = max(2, int(2 + age * .65))
                shade = GREEN if kind == "birth" else CORAL
                pygame.draw.circle(screen, shade, (px, py), r, 1)
        if len(selected_path) >= 2:
            for a, b in zip(selected_path, selected_path[1:]):
                ax, ay = map_to_screen(*a, ox, oy, pw, ph, units)
                bx, by = map_to_screen(*b, ox, oy, pw, ph, units)
                # Avoid falsely drawing a line across the wrap seam.
                if math.hypot(bx - ax, by - ay) < 12 * units:
                    pygame.draw.line(screen, (245, 201, 111), (ax, ay), (bx, by), 2)
        for j in range(world.population):
            px, py = map_to_screen(float(world.x[j]), float(world.y[j]), ox, oy, pw, ph, units)
            if not (ox + 3 <= px < ox + pw - 3 and oy + 3 <= py < oy + ph - 3):
                continue
            theta = float(world.angle[j])
            dx, dy = math.cos(theta), math.sin(theta)
            gen = int(world.generation[j])
            is_selected = selected_id is not None and int(world.ids[j]) == selected_id
            body = max(3, min(7, int(units * 0.42)))
            color = (min(255, 123 + 15 * gen), max(116, 206 - 5 * gen),
                     min(245, 190 + 2 * gen))
            if is_selected:
                pygame.draw.circle(screen, GOLD, (px, py), 13 + body, 2)
                pygame.draw.circle(screen, GOLD, (px, py), 19 + body, 1)
            tail = (int(px - dx * body * 1.6), int(py - dy * body * 1.6))
            pygame.draw.line(screen, (18, 33, 43), tail, (px, py), 2)
            tip = (int(px + dx * body * 1.4), int(py + dy * body * 1.4))
            left_wing = (int(px - dx * body * .5 - dy * body * .7),
                         int(py - dy * body * .5 + dx * body * .7))
            right_wing = (int(px - dx * body * .5 + dy * body * .7),
                          int(py - dy * body * .5 - dx * body * .7))
            pygame.draw.polygon(screen, (15, 28, 35), [tip, left_wing, right_wing], 0)
            pygame.draw.polygon(screen, color, [tip, left_wing, right_wing], 0)
        screen.set_clip(None)
        map_label = "FOOD STOCK" if show_food else "FOOD CAPACITY"
        box(pygame.Rect(ox + 11, oy + 11, 188, 31), (15, 31, 37), 7)
        caption(f"● {map_label}  |  {zoom_steps[zoom_index]:g}x", ox + 21, oy + 16, GREEN, small)
        if world.manual_interventions:
            box(pygame.Rect(ox + 12, oy + ph - 42, 248, 30), (75, 44, 38), 8)
            caption("INTERVENED · not a control run", ox + 19, oy + ph - 36, (255, 207, 161), small)
        elif sandbox_brush:
            box(pygame.Rect(ox + 12, oy + ph - 42, 224, 30), (40, 62, 45), 8)
            caption("SANDBOX BRUSH · click to feed", ox + 19, oy + ph - 36, GREEN, small)
        if world.population == 0:
            box(pygame.Rect(ox + pw // 2 - 200, oy + ph // 2 - 52, 400, 108), (33, 34, 38), 14, CORAL)
            caption("EXTINCTION", ox + pw // 2 - 95, oy + ph // 2 - 38, CORAL, big)
            caption("No organisms survived. Press R to restart.", ox + pw // 2 - 156,
                    oy + ph // 2 + 8, TEXT, small)

        # Clickable action row. Each button has an advertised working action.
        buttons.clear()
        commands = [("pause", "▶ PLAY" if pause else "Ⅱ PAUSE"),
                    ("step", "STEP"), ("slower", "− SPEED"),
                    ("faster", "+ SPEED"), ("zoom_out", "− ZOOM"),
                    ("zoom_in", "+ ZOOM"), ("follow", "FOLLOW"),
                    ("sandbox", "FEED BRUSH"), ("map", "HEATMAP"),
                    ("save", "SAVE")]
        usable = pw
        gap = 6
        bw = int((usable - gap * (len(commands) - 1)) / len(commands))
        toolbar_top = L.toolbar_y
        for index, (action, name) in enumerate(commands):
            rect = pygame.Rect(ox + index * (bw + gap), toolbar_top, bw, 33)
            button(rect, action, name, active=(sandbox_brush if action == "sandbox" else
                                               follow if action == "follow" else False))

        # Right side: legible contextual metrics, inspector, and short event feed.
        caption("WORLD STATUS", sx, sy, GREEN, small)
        box(pygame.Rect(sx, sy + 28, sw - 9, 126), PANEL, 12)
        metrics = (("ALIVE", f"{world.population:,}"), ("TICK", f"{world.tick:,}"),
                   ("BORN", f"{world.total_births:,}"), ("DIED", f"{world.total_deaths:,}"))
        for k, (title, value) in enumerate(metrics):
            cx = sx + 15 + (k % 2) * (sw - 18) / 2
            cy = sy + 37 + (k // 2) * 61
            caption(title, cx, cy, MUTED, micro)
            caption(value, cx, cy + 14, TEXT, num)
        line_y = sy + 174
        caption("POPULATION TREND", sx, line_y, GREEN, small)
        graph = pygame.Rect(sx, line_y + 24, sw - 9, 73)
        box(graph, PANEL, 9)
        if len(history) >= 2:
            t_min = history[0][0]
            t_max = max(t_min + 1, history[-1][0])
            top_pop = max(20, max(n for _, n, _ in history) * 1.12)
            coords = [(graph.x + 8 + (tick - t_min) / (t_max - t_min) * (graph.w - 16),
                       graph.y + graph.h - 9 - pop / top_pop * (graph.h - 18))
                      for tick, pop, _ in history]
            pygame.draw.lines(screen, GREEN, False, coords, 2)
        caption("SPECIMEN INSPECTOR", sx, graph.bottom + 16, GREEN, small)
        inspect_y = graph.bottom + 39
        inspect_h = 163
        box(pygame.Rect(sx, inspect_y, sw - 9, inspect_h), PANEL, 11)
        idx = (np.flatnonzero(world.ids == selected_id)
               if selected_id is not None else np.empty(0, dtype=int))
        if len(idx):
            j = int(idx[0])
            turn, speed, _ = world.controls()
            caption(f"# {selected_id}    •    GENERATION {int(world.generation[j])}",
                    sx + 12, inspect_y + 12, GOLD, small, sw - 32)
            caption(f"Energy  {float(world.energy[j]):.1f}    Age  {int(world.age[j])} / {world.config.lifespan}",
                    sx + 12, inspect_y + 37, TEXT, small)
            caption(f"Parent  #{int(world.parents[j])}    Intake  {float(world.last_intake[j]):.2f}",
                    sx + 12, inspect_y + 60, MUTED, small)
            caption(f"Speed  {float(speed[j]):.2f}    Turn  {float(turn[j]):+.2f} rad", sx + 12,
                    inspect_y + 84, MUTED, small)
            caption("ENERGY", sx + 12, inspect_y + 112, MUTED, micro)
            pygame.draw.rect(screen, (42, 57, 59), (sx + 90, inspect_y + 116, sw - 117, 10), border_radius=4)
            amount = min(1.0, float(world.energy[j]) / world.config.reproduction_threshold)
            pygame.draw.rect(screen, GREEN, (sx + 90, inspect_y + 116,
                                             int((sw - 117) * amount), 10), border_radius=4)
            caption("L follow · scroll zoom · right-drag pan", sx + 12, inspect_y + 138,
                    MUTED, micro, sw - 20)
        else:
            caption("Choose a moving organism on the map", sx + 13, inspect_y + 24, TEXT, small, sw - 30)
            caption("Watch its energy, parent, lifespan,", sx + 13, inspect_y + 53, MUTED, small)
            caption("food intake and motor decisions.", sx + 13, inspect_y + 76, MUTED, small)
            caption("Scroll to zoom; right-drag to pan.", sx + 13, inspect_y + 114, GREEN, small)
        feed_y = inspect_y + inspect_h + 16
        if feed_y + 65 < h - 79:
            caption("LATEST EVENTS", sx, feed_y, GREEN, small)
            box(pygame.Rect(sx, feed_y + 23, sw - 9, max(50, min(113, h - feed_y - 109))), PANEL, 10)
            for k, (tick, message) in enumerate(list(reversed(event_feed))[:3]):
                caption(f"T{tick:>5}   {message}", sx + 10, feed_y + 34 + k * 23,
                        GOLD if "died" in message else MUTED, micro, sw - 28)
            if not event_feed:
                caption("Births and deaths will appear here.", sx + 10, feed_y + 45, MUTED, small)

        # Bottom strip has a visible mode and top interactions rather than a
        # giant scrolling text line with clipped shortcut instructions.
        footer = (f"{'PAUSED' if pause else 'LIVE'}   {pacing[pace_index]:g} tick/frame   "
                  f"· growth {world.config.growth_rate:.3f}   · movement cost {world.config.move_cost:.2f}   "
                  f"· H help / J journal / I islands / B walls / C cost / [ ] growth / R restart")
        caption(footer, 27, h - 19, GREEN if not pause else GOLD, micro, w - 60)
        if frame < notice_until:
            box(pygame.Rect(ox + 5, oy + ph - 88, min(pw - 10, 515), 33), (27, 53, 56), 8)
            caption(notice, ox + 16, oy + ph - 82, TEXT, small, min(pw - 40, 490))
        if show_help:
            hrect = pygame.Rect(ox + max(20, (pw - 555) // 2), oy + 58, min(555, pw - 40), 330)
            box(hrect, (18, 37, 44), 14, GREEN)
            caption("FIELD GUIDE  ·  PRESS H TO CLOSE", hrect.x + 18, hrect.y + 17, GREEN, ui)
            explanations = (
                "CLICK a creature to inspect it. L follows the selected creature.",
                "MOUSE WHEEL zooms; RIGHT-DRAG pans; Z/X also zoom.",
                "SPACE pauses; N advances a single tick; +/- change pace.",
                "T toggles the SANDBOX BRUSH. Click terrain to add nutrients.",
                "SANDBOX interventions are logged in saved checkpoints.",
                "F changes terrain view; [ ] change growth live; I restarts layout.",
                "B switches wall mode; M moves patches; C changes motion cost.",
                "R restarts same seed; S saves state and screenshot; ESC exits.",
                "Genome rules, reproduction and mortality are NOT scripted.",
                "This is an evolving simulation, not evidence of consciousness.",
            )
            for k, line in enumerate(explanations):
                caption(line, hrect.x + 18, hrect.y + 61 + k * 24,
                        TEXT if k < 4 else MUTED, small, hrect.w - 40)
        if show_journal:
            jr = pygame.Rect(ox + max(20, (pw - 548) // 2), oy + 55, min(pw - 40, 548), 325)
            box(jr, (17, 37, 44), 13, GREEN)
            caption("FIELD NOTES  ·  J TO CLOSE", jr.x + 17, jr.y + 13, GREEN, ui)
            discoveries = (
                ("First descendant", world.total_births > 0),
                ("Five-generation lineage", bool(world.population and np.max(world.generation) >= 5)),
                ("Observed starvation", world.death_causes.get("starvation", 0) > 0),
                ("Observed old-age mortality", world.death_causes.get("age", 0) > 0),
                ("Observed relocation", world.patch_moves > 0),
                ("Changed the living environment", bool(world.manual_interventions)),
            )
            for k, (title, done) in enumerate(discoveries):
                caption(("✓  " if done else "○  ") + title,
                        jr.x + 22, jr.y + 55 + k * 36,
                        GREEN if done else MUTED, small, jr.w - 35)
            caption("These are recorded observations, not scripted achievements.",
                    jr.x + 17, jr.y + 285, MUTED, micro, jr.w - 24)
        pygame.display.flip()
        if pending_save:
            # Save AFTER rendering: previous versions captured the prior frame,
            # or a blank screen if S was pressed on the first frame.
            pending_save = False
            directory = Path("results/viewer")
            try:
                directory.mkdir(parents=True, exist_ok=True)
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
                saving_path = directory / f"world_{stamp}.npz"
                world.save(saving_path)
                pygame.image.save(screen, str(directory / f"screenshot_{stamp}.png"))
                announce(f"Saved world & screenshot to results/viewer/ · tick {world.tick}")
            except OSError as exc:
                announce(f"Save failed: {exc}")
        clock.tick(35)
    pygame.quit()
