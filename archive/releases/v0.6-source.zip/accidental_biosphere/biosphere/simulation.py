"""Accidental Biosphere: deterministic, vectorized, asynchronous-birth digital ecology.

There is NO scripted food seeking, social action, combat, parenting, or survival policy.
The genome maps local measurements to angular and forward motor commands.
Organisms acquire food from the grid cell they occupy; reproduction is triggered by
sufficient stored energy, not by a dedicated behavioral choice.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
from typing import Any

import numpy as np

# Each column is directly interpretable in the small linear neural controller.
SENSORS = ("bias", "food_ahead", "food_left", "food_right", "forward_contrast",
           "left_right_contrast", "energy_fraction", "crowding")
MOTORS = ("turn", "speed")
GENES = (2, len(SENSORS))


@dataclass(frozen=True)
class Config:
    width: int = 72
    height: int = 54
    founders: int = 180
    max_population: int = 900
    initial_energy: float = 32.0
    metabolism: float = 0.20
    move_cost: float = 0.065
    max_bite: float = 1.45
    food_gain: float = 1.75
    growth_rate: float = 0.030
    resource_background: float = 0.25
    resource_patchiness: float = 1.0
    resource_layout: str = "hills"  # hills / islands (spatially separated rare patches)
    island_count: int = 8
    island_sigma: float = 2.8
    island_peak: float = 10.0
    lifespan: int = 330
    reproduction_age: int = 15
    reproduction_threshold: float = 47.0
    reproduction_cost: float = 27.0
    newborn_energy: float = 22.0
    mutation_probability: float = 0.14
    mutation_strength: float = 0.28
    sensor_distance: float = 3.0
    max_turn: float = 0.60
    max_speed: float = 0.90
    boundary_mode: str = "wrap"  # wrap / reflect (specular bouncing)
    patch_shift_interval: int = 0  # zero = stationary; shift both food and capacity
    # Modes used in preregistered experimental interventions.
    sensor_mode: str = "normal"  # normal / blind / food_blind / crowd_blind / mirror_food
    # Experimental motor interventions, never enabled by the normal ecology.
    # Useful for distinguishing speed from steering when comparing genotypes.
    fixed_speed: float | None = None
    fixed_turn: float | None = None
    allow_reproduction: bool = True
    allow_mutation: bool = True

    def __post_init__(self) -> None:
        if self.width < 8 or self.height < 8 or self.founders < 0 or self.max_population < 1:
            raise ValueError("Invalid world dimensions or population")
        if self.founders > self.max_population:
            raise ValueError("Founder count cannot exceed population limit")
        if self.resource_layout not in ("hills", "islands"):
            raise ValueError("Unsupported resource_layout")
        if self.island_count < 1 or self.island_sigma <= 0 or self.island_peak <= 0:
            raise ValueError("Invalid island geometry")
        if self.resource_background < 0 or self.resource_patchiness < 0:
            raise ValueError("Invalid resource background or patchiness")
        if self.boundary_mode not in ("wrap", "reflect"):
            raise ValueError("Unsupported boundary_mode")
        if self.patch_shift_interval < 0:
            raise ValueError("patch_shift_interval must be nonnegative")
        if self.move_cost < 0:
            raise ValueError("move_cost must be nonnegative")
        if self.sensor_mode not in ("normal", "blind", "food_blind", "crowd_blind", "mirror_food"):
            raise ValueError("Unsupported sensor_mode")
        if self.fixed_speed is not None and not 0 <= self.fixed_speed <= self.max_speed:
            raise ValueError("fixed_speed must be between 0 and max_speed")
        if self.fixed_turn is not None and not -self.max_turn <= self.fixed_turn <= self.max_turn:
            raise ValueError("fixed_turn exceeds max_turn")
        if not (0 <= self.mutation_probability <= 1):
            raise ValueError("mutation_probability must be in [0, 1]")
        if self.newborn_energy > self.reproduction_cost:
            raise ValueError("Reproduction may not create energy")
        if self.reproduction_threshold <= self.reproduction_cost:
            raise ValueError("Reproduction must retain some parent energy")
        if self.metabolism < 0 or self.food_gain < 0 or not (0 <= self.growth_rate <= 1):
            raise ValueError("Invalid ecological rates")


def patch_landscape(config: Config, rng: np.random.Generator) -> np.ndarray:
    """Generate stationary resource-capacity hills, not fixed foraging routes."""
    yy, xx = np.mgrid[:config.height, :config.width]
    cap = np.full((config.height, config.width), config.resource_background,
                  dtype=np.float64)
    if config.resource_layout == "islands":
        # Environmental structure only. Organisms are never given the island
        # positions, objectives, or a navigation routine. Sampling is identical.
        centers: list[tuple[float, float]] = []
        min_sep = max(3.0, 3.8 * config.island_sigma)
        for _ in range(config.island_count):
            # Pick the best-spaced candidate out of a bounded random search.
            # This works even in tiny test arenas where perfect separation is
            # mathematically impossible. No seed-dependent unbounded loop.
            trials = rng.uniform([0, 0], [config.width, config.height], size=(80, 2))
            if centers:
                prior = np.asarray(centers)
                diff = np.abs(trials[:, None, :] - prior[None, :, :])
                if config.boundary_mode == "wrap":
                    diff = np.minimum(diff, np.array([config.width, config.height]) - diff)
                distances = np.sqrt(np.sum(diff ** 2, axis=2))
                scores = np.min(distances, axis=1)
                acceptable = np.flatnonzero(scores >= min_sep)
                idx = int(acceptable[0]) if len(acceptable) else int(np.argmax(scores))
            else:
                idx = 0
            cx, cy = map(float, trials[idx])
            centers.append((cx, cy))
            dx, dy = np.abs(xx - cx), np.abs(yy - cy)
            if config.boundary_mode == "wrap":
                dx, dy = np.minimum(dx, config.width - dx), np.minimum(dy, config.height - dy)
            cap += config.island_peak * np.exp(-0.5 * (dx * dx + dy * dy) / config.island_sigma ** 2)
        return np.clip(cap, 0.01, 12.0)
    # Smooth localized hills are periodic: no boundary discontinuity on torus.
    for _ in range(max(5, round(config.width * config.height / 220))):
        cx = rng.uniform(0, config.width)
        cy = rng.uniform(0, config.height)
        rx = rng.uniform(2.8, 8.0)
        ry = rng.uniform(2.8, 7.0)
        dx = np.abs(xx - cx)
        dy = np.abs(yy - cy)
        dx = np.minimum(dx, config.width - dx)
        dy = np.minimum(dy, config.height - dy)
        cap += config.resource_patchiness * rng.uniform(1.1, 3.8) * np.exp(
            -0.5 * ((dx / rx) ** 2 + (dy / ry) ** 2))
    return np.clip(cap, 0.05, 12.0)


class World:
    def __init__(self, config: Config | None = None, seed: int = 1,
                 founder_genomes: np.ndarray | None = None):
        self.config = config if config is not None else Config()
        self.seed = int(seed)
        self.rng = np.random.default_rng(self.seed)
        self.capacity = patch_landscape(self.config, self.rng)
        self.food = self.capacity.copy()
        n = self.config.founders if founder_genomes is None else len(founder_genomes)
        if n > self.config.max_population:
            raise ValueError("Too many founder genomes")
        self.x = self.rng.uniform(0, self.config.width, n)
        self.y = self.rng.uniform(0, self.config.height, n)
        self.angle = self.rng.uniform(-np.pi, np.pi, n)
        self.energy = np.full(n, self.config.initial_energy, dtype=np.float64)
        self.age = np.zeros(n, dtype=np.int32)
        self.ids = np.arange(n, dtype=np.int64)
        self.parents = np.full(n, -1, dtype=np.int64)
        self.generation = np.zeros(n, dtype=np.int32)
        self.genomes = (self.rng.normal(0, 0.7, (n, *GENES)) if founder_genomes is None
                        else np.asarray(founder_genomes, dtype=np.float64).copy())
        if self.genomes.shape != (n, *GENES):
            raise ValueError(f"Genomes must have shape (n, {GENES[0]}, {GENES[1]})")
        self.tick = 0
        self.next_id = n
        self.total_births = 0
        self.total_deaths = 0
        self.total_harvest = 0.0
        self.death_causes: dict[str, int] = {"starvation": 0, "age": 0}
        self.last_events: list[dict[str, Any]] = []
        self.last_mean_intake = 0.0
        self.last_total_intake = 0.0
        self.last_mean_speed = 0.0
        self.last_directionality = 0.0
        self.last_wall_hits = 0
        self.cumulative_wall_hits = 0
        self.patch_moves = 0
        # Inspector-only data, aligned with *currently living* organism IDs.
        # Neither changes motor outputs nor consumes random numbers.
        self.last_intake = np.zeros(n, dtype=np.float64)
        # Manual terrain edits are isolated to the viewer's explicitly labeled
        # sandbox mode; experiments never call fertilize().
        self.manual_interventions: list[dict[str, Any]] = []

    def fertilize(self, x: float, y: float, *, radius: float = 2.4,
                  strength: float = 3.0) -> float:
        """Sandbox-only brush: increase carrying capacity and matching food.

        Deterministic, bounded and saved as an intervention. Replaces neither
        genomes nor survival policies; marks the environment as manipulated.
        """
        if not (np.isfinite(x) and np.isfinite(y) and np.isfinite(radius) and
                np.isfinite(strength) and radius > 0 and strength > 0):
            raise ValueError("Invalid fertilize brush parameters")
        yy, xx = np.mgrid[:self.config.height, :self.config.width]
        dx, dy = np.abs(xx - x), np.abs(yy - y)
        if self.config.boundary_mode == "wrap":
            dx = np.minimum(dx, self.config.width - dx)
            dy = np.minimum(dy, self.config.height - dy)
        bloom = strength * np.exp(-0.5 * (dx * dx + dy * dy) / radius ** 2)
        new_capacity = np.minimum(self.capacity + bloom, 12.0)
        added = new_capacity - self.capacity
        self.capacity = new_capacity
        self.food = np.minimum(self.food + added, self.capacity)
        amount = float(np.sum(added))
        self.manual_interventions.append({"tick": self.tick, "kind": "fertilize",
                                          "x": float(x), "y": float(y),
                                          "radius": float(radius), "added": amount})
        return amount

    @property
    def population(self) -> int:
        return len(self.x)

    @staticmethod
    def _reflect_coordinate(pos: np.ndarray, limit: int) -> np.ndarray:
        """Mirrored extension of a closed wall, safe at exact grid limits."""
        projected = np.mod(pos, 2 * limit)
        reflected = np.where(projected < limit, projected, 2 * limit - projected)
        return np.minimum(reflected, np.nextafter(float(limit), 0.0))

    def _cells(self, x: np.ndarray, y: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        if self.config.boundary_mode == "wrap":
            return np.floor(y).astype(np.intp) % self.config.height, np.floor(x).astype(np.intp) % self.config.width
        cy = self._reflect_coordinate(y, self.config.height)
        cx = self._reflect_coordinate(x, self.config.width)
        return np.floor(cy).astype(np.intp), np.floor(cx).astype(np.intp)

    def _sample_food(self, x: np.ndarray, y: np.ndarray) -> np.ndarray:
        iy, ix = self._cells(x, y)
        # Absolute available energy density (normalized), not percent full.
        # Otherwise organisms could never detect a rich patch at initial saturation.
        return np.clip(self.food[iy, ix] / 12.0, 0, 1)

    def perceive(self) -> np.ndarray:
        """Neural input in egocentric orientation. No action is hardcoded."""
        n = self.population
        if n == 0:
            return np.empty((0, len(SENSORS)), dtype=np.float64)
        d = self.config.sensor_distance
        offsets = (0, np.pi / 3, -np.pi / 3)
        fs = [self._sample_food(self.x + d * np.cos(self.angle + o),
                                self.y + d * np.sin(self.angle + o))
              for o in offsets]
        f, l, r = fs
        iy, ix = self._cells(self.x, self.y)
        counts = np.bincount(iy * self.config.width + ix, minlength=self.config.height * self.config.width)
        crowd = np.minimum(counts[iy * self.config.width + ix] - 1, 8) / 8.0
        state = np.stack((np.ones(n), f, l, r, f - (l + r) / 2, l - r,
                          np.clip(self.energy / self.config.reproduction_threshold, 0, 2),
                          crowd), axis=1)
        if self.config.sensor_mode == "blind":
            # Retain the internal energy signal & bias; blind only external senses.
            state[:, 1:6] = 0.0
            state[:, 7] = 0.0
        elif self.config.sensor_mode == "food_blind":
            state[:, 1:6] = 0.0
        elif self.config.sensor_mode == "crowd_blind":
            state[:, 7] = 0.0
        elif self.config.sensor_mode == "mirror_food":
            # Preserve forward readings and lateral magnitude, but reverse
            # their compass directions. This is a causal intervention, not
            # natural evolution or a trained behavior.
            state[:, [2, 3]] = state[:, [3, 2]]
            state[:, 5] *= -1
        return state

    def controls(self) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        sensors = self.perceive()
        if not len(sensors):
            return np.empty(0), np.empty(0), sensors
        outputs = np.einsum("nij,nj->ni", self.genomes, sensors)
        turn = np.tanh(outputs[:, 0]) * self.config.max_turn
        # Linear controller output squashed to a nonnegative propulsion magnitude.
        speed = (0.05 + 0.95 / (1 + np.exp(-np.clip(outputs[:, 1], -20, 20)))) * self.config.max_speed
        if self.config.fixed_speed is not None:
            speed = np.full(len(speed), self.config.fixed_speed)
        if self.config.fixed_turn is not None:
            turn = np.full(len(turn), self.config.fixed_turn)
        return turn, speed, sensors

    def step(self) -> dict[str, Any]:
        cfg = self.config
        self.tick += 1
        self.last_events = []
        self.last_wall_hits = 0
        if cfg.patch_shift_interval and self.tick % cfg.patch_shift_interval == 0:
            # Move both the food stock and the carrying-capacity landscape:
            # patches relocate without instantly creating or deleting food.
            sx = int(self.rng.integers(6, max(7, cfg.width // 3 + 1)))
            sy = int(self.rng.integers(6, max(7, cfg.height // 3 + 1)))
            # Include both directions; environmental movement is not learned.
            sx *= int(self.rng.choice((-1, 1)))
            sy *= int(self.rng.choice((-1, 1)))
            self.capacity = np.roll(self.capacity, (sy, sx), axis=(0, 1))
            self.food = np.roll(self.food, (sy, sx), axis=(0, 1))
            self.patch_moves += 1
        n = self.population
        if n == 0:
            self.food += cfg.growth_rate * (self.capacity - self.food)
            self.last_mean_intake = 0.0
            self.last_total_intake = 0.0
            self.last_mean_speed = 0.0
            self.last_directionality = 0.0
            self.last_intake = np.empty(0, dtype=np.float64)
            return self.stats(0, 0, detailed=False)

        turn, speed, senses = self.controls()
        self.last_mean_speed = float(np.mean(speed))
        contrast = senses[:, 5]
        self.last_directionality = float(np.mean(turn * contrast)) if cfg.sensor_mode == "normal" else 0.0
        self.angle = (self.angle + turn + np.pi) % (2 * np.pi) - np.pi
        next_x = self.x + speed * np.cos(self.angle)
        next_y = self.y + speed * np.sin(self.angle)
        if cfg.boundary_mode == "wrap":
            self.x = next_x % cfg.width
            self.y = next_y % cfg.height
        else:
            hit_x = (next_x < 0) | (next_x >= cfg.width)
            hit_y = (next_y < 0) | (next_y >= cfg.height)
            self.last_wall_hits = int(np.count_nonzero(hit_x | hit_y))
            self.cumulative_wall_hits += self.last_wall_hits
            self.x = self._reflect_coordinate(next_x, cfg.width)
            self.y = self._reflect_coordinate(next_y, cfg.height)
            self.angle = np.where(hit_x, np.pi - self.angle, self.angle)
            self.angle = np.where(hit_y, -self.angle, self.angle)
            self.angle = (self.angle + np.pi) % (2 * np.pi) - np.pi
        self.age += 1

        iy, ix = self._cells(self.x, self.y)
        indices = iy * cfg.width + ix
        # Simultaneous, equitable sharing: np.add.at avoids repeated-index over-crediting.
        counts = np.bincount(indices, minlength=cfg.height * cfg.width)
        intake = np.minimum(cfg.max_bite, self.food[iy, ix] / counts[indices])
        np.add.at(self.food, (iy, ix), -intake)
        self.food = np.clip(self.food, 0, self.capacity)
        self.last_intake = intake.copy()
        self.last_mean_intake = float(np.mean(intake))
        self.last_total_intake = float(np.sum(intake))
        self.total_harvest += self.last_total_intake
        self.energy += intake * cfg.food_gain - cfg.metabolism - speed * cfg.move_cost
        dead_starvation = self.energy <= 0
        dead_old = self.age >= cfg.lifespan
        dead = dead_starvation | dead_old
        self.death_causes["starvation"] += int(np.sum(dead_starvation))
        self.death_causes["age"] += int(np.sum(dead_old & ~dead_starvation))
        died = int(np.sum(dead))
        if died:
            for dead_idx in np.flatnonzero(dead):
                self.last_events.append({"tick": self.tick, "kind": "death",
                                         "id": int(self.ids[dead_idx]),
                                         "cause": "starvation" if dead_starvation[dead_idx] else "age",
                                         "x": float(self.x[dead_idx]), "y": float(self.y[dead_idx])})
            self._retain(~dead)
            self.last_intake = self.last_intake[~dead]
            self.total_deaths += died

        born = 0
        if cfg.allow_reproduction and self.population < cfg.max_population:
            candidates = np.flatnonzero((self.age >= cfg.reproduction_age) &
                                         (self.energy >= cfg.reproduction_threshold))
            self.rng.shuffle(candidates)  # cap is allocated without agent-id priority
            candidates = candidates[:cfg.max_population - self.population]
            born = len(candidates)
            if born:
                parent_ids = self.ids[candidates].copy()
                newborn_ids = np.arange(self.next_id, self.next_id + born, dtype=np.int64)
                self.next_id += born
                child_genomes = self.genomes[candidates].copy()
                if cfg.allow_mutation and cfg.mutation_probability:
                    mask = self.rng.random(child_genomes.shape) < cfg.mutation_probability
                    child_genomes += mask * self.rng.normal(0, cfg.mutation_strength, child_genomes.shape)
                    np.clip(child_genomes, -5, 5, out=child_genomes)
                child_x = self.x[candidates] + self.rng.normal(0, 1.3, born)
                child_y = self.y[candidates] + self.rng.normal(0, 1.3, born)
                if cfg.boundary_mode == "wrap":
                    child_x %= cfg.width
                    child_y %= cfg.height
                else:
                    child_x = self._reflect_coordinate(child_x, cfg.width)
                    child_y = self._reflect_coordinate(child_y, cfg.height)
                child_angle = self.rng.uniform(-np.pi, np.pi, born)
                child_generation = self.generation[candidates] + 1
                self.energy[candidates] -= cfg.reproduction_cost
                self.x = np.concatenate((self.x, child_x))
                self.y = np.concatenate((self.y, child_y))
                self.angle = np.concatenate((self.angle, child_angle))
                self.energy = np.concatenate((self.energy, np.full(born, cfg.newborn_energy)))
                self.age = np.concatenate((self.age, np.zeros(born, dtype=np.int32)))
                self.ids = np.concatenate((self.ids, newborn_ids))
                self.parents = np.concatenate((self.parents, parent_ids))
                self.generation = np.concatenate((self.generation, child_generation))
                self.genomes = np.concatenate((self.genomes, child_genomes))
                self.last_intake = np.concatenate((self.last_intake, np.zeros(born)))
                self.total_births += born
                self.last_events.extend({"tick": self.tick, "kind": "birth", "id": int(id_),
                                         "parent_id": int(parent), "generation": int(gen),
                                         "x": float(cx), "y": float(cy)}
                                        for id_, parent, gen, cx, cy in
                                        zip(newborn_ids, parent_ids, child_generation, child_x, child_y))

        self.food += cfg.growth_rate * (self.capacity - self.food)
        return self.stats(born, died, detailed=False)

    def _retain(self, mask: np.ndarray) -> None:
        for field in ("x", "y", "angle", "energy", "age", "ids", "parents", "generation", "genomes"):
            setattr(self, field, getattr(self, field)[mask])

    def stats(self, births: int = 0, deaths: int = 0, *, detailed: bool = True) -> dict[str, Any]:
        n = self.population
        return {"tick": self.tick, "population": n, "births": births, "deaths": deaths,
                "cumulative_births": self.total_births, "cumulative_deaths": self.total_deaths,
                "max_generation": int(np.max(self.generation)) if n else 0,
                "mean_generation": float(np.mean(self.generation)) if n else 0.0,
                "mean_energy": float(np.mean(self.energy)) if n else 0.0,
                "mean_age": float(np.mean(self.age)) if n else 0.0,
                "mean_intake": self.last_mean_intake,
                "mean_speed": self.last_mean_speed,
                "directionality": self.last_directionality,
                "wall_hits": self.last_wall_hits, "cumulative_wall_hits": self.cumulative_wall_hits,
                "patch_moves": self.patch_moves,
                "resource_stock": float(np.sum(self.food)),
                "genetic_diversity": float(np.mean(np.std(self.genomes.reshape(n, -1), axis=0))) if n > 1 and detailed else 0.0,
                "cumulative_harvest": self.total_harvest}

    def save(self, path: str | Path) -> None:
        """Full deterministic continuation, including RNG bit-generator state."""
        state = {"seed": self.seed, "tick": self.tick, "next_id": self.next_id,
                 "total_births": self.total_births, "total_deaths": self.total_deaths,
                 "total_harvest": self.total_harvest, "death_causes": self.death_causes,
                 "last_mean_intake": self.last_mean_intake, "last_total_intake": self.last_total_intake,
                 "last_mean_speed": self.last_mean_speed,
                 "last_directionality": self.last_directionality,
                 "last_wall_hits": self.last_wall_hits,
                 "cumulative_wall_hits": self.cumulative_wall_hits,
                 "patch_moves": self.patch_moves,
                 "manual_interventions": self.manual_interventions,
                 "config": asdict(self.config), "rng_state": self.rng.bit_generator.state}
        arrays = {name: getattr(self, name) for name in
                  ("capacity", "food", "x", "y", "angle", "energy", "age", "ids", "parents", "generation", "genomes", "last_intake")}
        np.savez_compressed(path, state=json.dumps(state), **arrays)

    @classmethod
    def load(cls, path: str | Path) -> World:
        with np.load(path, allow_pickle=False) as data:
            state = json.loads(str(data["state"]))
            world = cls(Config(**state["config"]), seed=state["seed"])
            for name in ("capacity", "food", "x", "y", "angle", "energy", "age", "ids", "parents", "generation", "genomes"):
                setattr(world, name, data[name].copy())
            world.last_intake = data["last_intake"].copy() if "last_intake" in data else np.zeros(world.population)
        for name in ("tick", "next_id", "total_births", "total_deaths", "total_harvest",
                     "death_causes", "last_mean_intake", "last_total_intake", "last_mean_speed", "last_directionality",
                     "last_wall_hits", "cumulative_wall_hits", "patch_moves"):
            # Older v0.1/v0.2 checkpoints predate the geometry observables.
            setattr(world, name, state.get(name, 0))
        world.manual_interventions = state.get("manual_interventions", [])
        world.rng.bit_generator.state = state["rng_state"]
        return world
