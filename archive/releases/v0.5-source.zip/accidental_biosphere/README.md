# The Accidental Biosphere — v0.5

**An evolving digital ecosystem you can observe, inspect, and experiment with.** This is a research-first artificial-life prototype with a growing interactive Pygame observatory. Its inhabitants are not scripted animals or proven intelligent beings.

Organisms inherit 16 motor-controller weights (two outputs × eight sensory inputs), experience energy costs, harvest local renewable food, reproduce with mutation, age and die. Whether an organism turns or travels quickly is determined by its inherited controller, not a programmed command to seek food. All experiments run headlessly with deterministic seeds and checkpoint replay.

## Quick start on Windows

1. Install **Python 3.10+**. If possible, select **Add Python to PATH**.
2. Extract the complete downloaded ZIP to a writable folder.
3. Double-click **`run_windows.bat`** to install the required Python packages and open the viewer. It supports both `py -3` and `python` launchers.

Alternatively, in a command prompt inside the extracted folder:

```powershell
python -m pip install -r requirements.txt
python -m biosphere view
```

To watch an actual evolved sparse-world population instead of starting with random founders:

```powershell
python -m biosphere view --resume results/experiment_004/checkpoints/seed_701_islands.npz
```

**Note:** This is Python source, not a compiled Windows `.exe`. This environment could not install Pygame, so the graphical window remains unverified on Windows. The included `observatory_visual_preview.png` is a Pillow-generated design preview using real simulation data, **not** an actual screenshot of the Pygame application.

## What you can do in the v0.5 viewer

- Follow actual organisms as they move; inspect parent ID, generation, age, energy, food intake and live speed/turn commands.
- Watch birth and death markers, a population sparkline, small event feed, and a six-observation field journal.
- Pan, zoom, pause, step through time or run much faster. Compare food-stock and capacity heatmaps.
- Restart the original seed with different wall, island, patch-shift, resource growth and movement-cost settings.
- Toggle the **SANDBOX FEED BRUSH** to expand food patches with the mouse. Edits are recorded and visibly tagged **INTERVENED — not a control run**; they are never included in reproducible research commands. Live environment changes are logged and marked as interventions too; a restart with selected settings clears this label.
- Save the full simulation and a screenshot in `results/viewer/` with microsecond-unique filenames.

### Viewer controls

| Input | Effect |
| --- | --- |
| **Left click** | Select nearest nearby organism / use clickable action bar |
| **Mouse wheel** or `Z` / `X` | Zoom in / out |
| **Right-drag** | Pan camera (stops following the current specimen) |
| `L` | Follow or stop following selected organism |
| `Space` / `N` | Pause or resume / single-step (also pauses) |
| `+` / `-` | Faster / slower, from 0.25 to 25 ticks per frame |
| `F` | Food remaining / carrying-capacity heatmap |
| `T` | Toggle sandbox nutrient brush; click ground to fertilize |
| `J` / `H` | Field journal / help overlay |
| `I` / `R` | Switch hills ↔ islands and restart / restart same seed and settings |
| `B` / `M` / `C` | Reflecting or wrap boundaries / moving food patches / motion energy cost |
| `[` / `]` | Lower / raise resource regrowth while world is running |
| `S` / `Esc` | Save checkpoint and screenshot / exit |

Primary controls also have clickable toolbar buttons. The viewer starts at 1 simulation step per frame (~35 steps/sec), not v0.4's 3 steps per frame × 40 frames/sec.

## Experiment 005: find a food patch or remain in one?

The v0.4 studies found that removing steering improved direct target encounters but steering improved resource collection once food was available. v0.5 separates **search** from **residency** with two matched assays.

- **256 experimental trials:** eight independent training seeds × four genome groups × two starting conditions × four motor interventions.
- Each trial tracks 36 organisms, all at externally fixed forward speed 0.60, for 75 ticks, without reproduction or mutation.
- Costly-island-trained organisms entered a food core from a distant start in **33.7%** of normal-controller cases versus **74.3%** with steering disabled.
- When they began inside a core, normal controllers spent **80.9%** of the assay inside a core, versus **14.7%** with steering disabled. Their average intake was **1.351** versus **0.543** food units/organism/tick.
- Critically, removing food sensors did **not** abolish local residency: **83.0%** occupancy in food-blind controllers. **Persistent turning may be responsible, not deliberate food-seeking.**

See [`docs/EXPERIMENT_005.md`](docs/EXPERIMENT_005.md) for complete procedure, seed-paired contrasts, caveats and limitations. This was an **exploratory analysis of existing evolved checkpoints**, not independently preregistered evidence of intelligence or planning.

### Reproduce Experiment 005

```powershell
python -m biosphere residency --seed-start 701 --seeds 8 --ticks 75 --trained-results results/experiment_004 --output results/my_residency_replay
python experiments/plot_residency.py
python -m pytest -q
```

The `trials.csv` and `summary.json` in `results/experiment_005/` are the raw and aggregate evidence. Precomputed charts are `search_arrival.png`, `core_residency.png`, `resident_harvest.png` and `sensory_ablations.png`.

## Other command-line workflows

```powershell
python -m biosphere run --seed 5 --steps 3000 --events --output results/my_world
python -m biosphere run --resume results/my_world/world.npz --steps 1000 --output results/continued
python -m biosphere navigation --seed-start 701 --seeds 8 --steps 1000 --probe-ticks 180 --count 120 --output results/my_navigation
python -m biosphere isolate --seed-start 701 --seeds 8 --count 120 --probe-ticks 180 --trained-results results/experiment_004 --output results/my_isolation
```

Older experiments also have the subcommands `experiment`, `investigate`, and `environment`. Run `python -m biosphere --help` for all commands and `python -m biosphere view --help` for viewer options. Every run can be resumed through a `.npz` checkpoint; the full NumPy generator state is included and `allow_pickle=False` is used during loading.

## Visual/game-design audit, science and QA

- [`docs/VISUAL_AUDIT.md`](docs/VISUAL_AUDIT.md): actual v0.4 visual/code audit, changes in v0.5, and what remains unverified.
- [`docs/EXPERIMENT_001.md`](docs/EXPERIMENT_001.md) to [`docs/EXPERIMENT_005.md`](docs/EXPERIMENT_005.md): successive experimental findings, successful and failed predictions.
- [`docs/MODEL.md`](docs/MODEL.md): world state, sensing, motor outputs, energy transfer, reproduction.
- [`docs/RESEARCH.md`](docs/RESEARCH.md): precedent and citation list for Tierra, Avida and Polyworld.
- [`docs/JOURNAL.md`](docs/JOURNAL.md): ongoing research log.
- [`docs/QA.md`](docs/QA.md): test coverage, scientific reproducibility and graphical limitations.

**Limitations:** This system cannot currently learn within a lifetime, invent anatomy, communicate, have offspring-care behavior, create social structures, or reliably orient toward a distant target. It is more engaging as a microscope than v0.4, but it is not yet a complete strategy game. Graphical UX needs independent test coverage on an actual desktop with Pygame.

License: MIT, see `LICENSE`. Third-party literature and software were referenced, not incorporated as source code.
