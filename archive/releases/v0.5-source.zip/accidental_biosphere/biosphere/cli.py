"""CLI: python -m biosphere ..."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from .simulation import Config, World


def simulate(args: argparse.Namespace) -> None:
    cfg = Config(founders=args.founders, max_population=args.max_population,
                 sensor_mode=args.sensor_mode, allow_mutation=not args.no_mutation,
                 mutation_strength=args.mutation_strength, growth_rate=args.growth_rate,
                 resource_patchiness=args.patchiness,
                 resource_background=(args.resource_background if args.resource_background is not None
                                      else (0.01 if args.resource_layout == "islands" else 0.25)),
                 resource_layout=args.resource_layout,
                 island_count=args.island_count, island_sigma=args.island_sigma,
                 island_peak=args.island_peak, boundary_mode=args.boundary_mode,
                 patch_shift_interval=args.patch_shift_interval, move_cost=args.move_cost)
    world = World.load(args.resume) if args.resume else World(cfg, seed=args.seed)
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    with (out / "metrics.csv").open("w", newline="", encoding="utf-8") as metrics, \
         (out / "lineage.csv").open("w", newline="", encoding="utf-8") as lineage:
        writer = csv.DictWriter(metrics, fieldnames=list(world.stats().keys()))
        writer.writeheader()
        lw = csv.DictWriter(lineage, fieldnames=["tick", "kind", "id", "parent_id", "generation", "cause", "x", "y"])
        if args.events:
            lw.writeheader()
        writer.writerow(world.stats())
        for _ in range(args.steps):
            stats = world.step()
            if args.events:
                for event in world.last_events:
                    lw.writerow(event)
            if world.tick % args.sample_every == 0 or world.population == 0:
                writer.writerow(world.stats(stats["births"], stats["deaths"]))
            if world.population == 0:
                print(f"Population went extinct at tick {world.tick}.")
                break
    world.save(out / "world.npz")
    report = {"seed": world.seed, "steps_completed": world.tick,
              "config": vars(world.config), "final": world.stats(),
              "death_causes": world.death_causes}
    (out / "summary.json").write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report["final"], indent=2))
    print(f"Files written to {out.resolve()}")


def main() -> None:
    parser = argparse.ArgumentParser(prog="biosphere", description="An evolving digital ecosystem")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("run", help="Headless reproducible evolution")
    p.add_argument("--seed", type=int, default=1)
    p.add_argument("--steps", type=int, default=3000)
    p.add_argument("--founders", type=int, default=180)
    p.add_argument("--max-population", type=int, default=900)
    p.add_argument("--sensor-mode", choices=("normal", "blind", "food_blind", "crowd_blind", "mirror_food"), default="normal")
    p.add_argument("--no-mutation", action="store_true")
    p.add_argument("--mutation-strength", type=float, default=0.28)
    p.add_argument("--growth-rate", type=float, default=0.030)
    p.add_argument("--patchiness", type=float, default=1.0)
    p.add_argument("--resource-layout", choices=("hills", "islands"), default="hills")
    p.add_argument("--resource-background", type=float,
                   help="Background food capacity (defaults: 0.25 hills, 0.01 islands)")
    p.add_argument("--island-count", type=int, default=8)
    p.add_argument("--island-sigma", type=float, default=2.8)
    p.add_argument("--island-peak", type=float, default=10.0)
    p.add_argument("--boundary-mode", choices=("wrap", "reflect"), default="wrap")
    p.add_argument("--patch-shift-interval", type=int, default=0)
    p.add_argument("--move-cost", type=float, default=0.065)
    p.add_argument("--resume", type=Path)
    p.add_argument("--sample-every", type=int, default=25)
    p.add_argument("--events", action="store_true", help="Save every birth/death to lineage.csv")
    p.add_argument("--output", default="results/run")
    p.set_defaults(func=simulate)
    v = sub.add_parser("view", help="Pygame ecosystem viewer")
    v.add_argument("--seed", type=int, default=1)
    v.add_argument("--resume", type=Path)
    v.add_argument("--max-population", type=int, default=900)
    v.add_argument("--boundary-mode", choices=("wrap", "reflect"), default="wrap")
    v.add_argument("--patch-shift-interval", type=int, default=0)
    v.add_argument("--move-cost", type=float, default=0.065)
    v.add_argument("--resource-layout", choices=("hills", "islands"), default="hills")
    v.add_argument("--resource-background", type=float,
                   help="Background food capacity (defaults: 0.25 hills, 0.01 islands)")
    v.add_argument("--island-count", type=int, default=8)
    v.add_argument("--island-sigma", type=float, default=2.8)
    v.add_argument("--island-peak", type=float, default=10.0)
    v.set_defaults(func=lambda a: __import__("biosphere.viewer", fromlist=["view"]).view(a))
    e = sub.add_parser("experiment", help="Multi-seed controlled selection experiment")
    e.add_argument("--seeds", type=int, default=6)
    e.add_argument("--steps", type=int, default=2200)
    e.add_argument("--probe-ticks", type=int, default=260)
    e.add_argument("--output", type=Path, default=Path("results/experiment"))
    e.set_defaults(func=lambda a: __import__("biosphere.experiment", fromlist=["run_experiment"]).run_experiment(a))
    inv = sub.add_parser("investigate", help="Holdout tests of movement and regrowth scarcity")
    inv.add_argument("--seed-start", type=int, default=101)
    inv.add_argument("--seeds", type=int, default=18)
    inv.add_argument("--steps", type=int, default=1200)
    inv.add_argument("--probe-ticks", type=int, default=240)
    inv.add_argument("--output", type=Path, default=Path("results/experiment_002"))
    inv.set_defaults(func=lambda a: __import__("biosphere.investigation", fromlist=["run_investigation"]).run_investigation(
        seeds=list(range(a.seed_start, a.seed_start+a.seeds)), steps=a.steps,
        probe_ticks=a.probe_ticks, output=a.output))
    env = sub.add_parser("environment", help="Experiment 003: boundary conditions and habitat shifts")
    env.add_argument("--seed-start", type=int, default=401)
    env.add_argument("--seeds", type=int, default=8)
    env.add_argument("--steps", type=int, default=900)
    env.add_argument("--probe-ticks", type=int, default=160)
    env.add_argument("--count", type=int, default=160)
    env.add_argument("--output", type=Path, default=Path("results/experiment_003_custom"))
    env.add_argument("--no-checkpoints", action="store_true")
    env.set_defaults(func=lambda a: __import__("biosphere.environment", fromlist=["run_environment_experiment"]).run_environment_experiment(
        seeds=list(range(a.seed_start, a.seed_start+a.seeds)), steps=a.steps,
        probe_ticks=a.probe_ticks, count=a.count, output=a.output,
        save_checkpoints=not a.no_checkpoints))
    nav = sub.add_parser("navigation", help="Experiment 004: separated food islands & navigation ablations")
    nav.add_argument("--seed-start", type=int, default=701)
    nav.add_argument("--seeds", type=int, default=8)
    nav.add_argument("--steps", type=int, default=1000)
    nav.add_argument("--probe-ticks", type=int, default=180)
    nav.add_argument("--count", type=int, default=120)
    nav.add_argument("--output", type=Path, default=Path("results/experiment_004_custom"))
    nav.add_argument("--no-checkpoints", action="store_true")
    nav.set_defaults(func=lambda a: __import__("biosphere.navigation", fromlist=["run_navigation_experiment"]).run_navigation_experiment(
        seeds=list(range(a.seed_start, a.seed_start+a.seeds)), steps=a.steps,
        probe_ticks=a.probe_ticks, count=a.count, output=a.output,
        save_checkpoints=not a.no_checkpoints))
    iso = sub.add_parser("isolate", help="Experiment 004B: steering-only causal ablations at fixed speed")
    iso.add_argument("--seed-start", type=int, default=701)
    iso.add_argument("--seeds", type=int, default=8)
    iso.add_argument("--count", type=int, default=120)
    iso.add_argument("--probe-ticks", type=int, default=180)
    iso.add_argument("--trained-results", type=Path, default=Path("results/experiment_004"))
    iso.add_argument("--output", type=Path, default=Path("results/experiment_004"))
    iso.set_defaults(func=lambda a: __import__("biosphere.navigation", fromlist=["run_motor_isolation"]).run_motor_isolation(
        seeds=list(range(a.seed_start, a.seed_start + a.seeds)), count=a.count,
        probe_ticks=a.probe_ticks, trained_results=a.trained_results, output=a.output))
    res = sub.add_parser("residency", help="Experiment 005: separate search from patch exploitation")
    res.add_argument("--seed-start", type=int, default=701)
    res.add_argument("--seeds", type=int, default=8)
    res.add_argument("--ticks", type=int, default=75)
    res.add_argument("--trained-results", type=Path, default=Path("results/experiment_004"))
    res.add_argument("--output", type=Path, default=Path("results/experiment_005"))
    res.set_defaults(func=lambda a: __import__("biosphere.residency", fromlist=["run_residency"]).run_residency(
        seeds=list(range(a.seed_start, a.seed_start + a.seeds)), ticks=a.ticks,
        trained_results=a.trained_results, output=a.output, progress=True))
    args = parser.parse_args()
    if hasattr(args, "sample_every") and args.sample_every < 1:
        parser.error("--sample-every must be positive")
    args.func(args)

if __name__ == "__main__":
    main()
