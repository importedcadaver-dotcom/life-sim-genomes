# QA and verification

**Last automated test run: 2026-11-02. Current version: v0.2.**

| Check | Status |
| --- | --- |
| Python modules syntax check | PASS (`compileall`) |
| Identical seeds replay identically | PASS |
| Different seeds generate different terrain | PASS |
| Resource cell never becomes negative under many overlapping agents | PASS |
| Birth uses valid parent IDs and generation increment | PASS |
| Simulated reproduction cannot push above population cap | PASS |
| Checkpoint continuation equals uninterrupted simulation | PASS |
| New checkpoint preserves aggregate measurements | PASS |
| Senses can be removed for intervention | PASS |
| Extinct population remains extinct | PASS |
| Mutations disabled means genome copies are exact | PASS |
| Unphysical/invalid configurations rejected | PASS |
| No food plus metabolism reduces energy | PASS |
| Repeated common-garden evaluation with same seed is deterministic | PASS |
| Full headless CLI run and CSV/NPZ export | PASS |
| Six-seed common-garden experiment outputs data and charts | PASS |
| Independent Experiment 002: 18 seeds × 5 scarcity levels | PASS |
| Synthetic cue-response assay with known genome signs | PASS |
| Effective collapsed genes exactly reproduce raw neural dot products | PASS |
| Mirroring lateral food signals preserves all non-lateral channels | PASS |
| Independent food and crowding sensor ablations | PASS |
| Fixed speed/turn overrides preserve inherited genomes | PASS |
| Experimental motor overrides survive deterministic checkpoint continuation | PASS |
| Scarcity treatments share exact initial conditions before divergence | PASS |
| Empty/extinct training populations not silently resurrected in tests | PASS |
| Deterministic replay reproduces 57 recorded seed-101 CSV rows exactly | PASS |
| Real saved-world snapshot rendering | PASS |
| Pygame viewer actually launches and accepts controls | **UNVERIFIED**: Pygame package unavailable in this environment |
| Windows .bat actually launches on Windows | **UNVERIFIED**: Linux runner cannot reproduce Windows environment |
| Distribution as a precompiled Windows `.exe` | **NOT PROVIDED** |
| External review by domain scientist | **NOT DONE** |

**21 automated tests currently pass.** Tests are in `tests/test_simulation.py` and `tests/test_investigation.py`. Run `python -m pytest -q` after extracting. In addition, seed 101 of Experiment 002 was rerun with identical parameters: all five training outcomes, 26 probe outcomes, two controller-response rows and 24 effective-gene rows were identical to the original run.

### Notes

- Deterministic tests are for the same code/runtime environment. Numerical results may vary across NumPy versions.
- Long runs reached the cap of 900 individuals; more tests are needed to quantify any cap-induced evolutionary effect.
- Stored checkpoints include NumPy arrays and serialized JSON RNG state; loading uses `allow_pickle=False`.
- Results are exploratory; the six training seeds are the independent units of replication.
- The first tested terrain issue is described transparently in `JOURNAL.md`.
