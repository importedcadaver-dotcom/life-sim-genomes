# The Accidental Biosphere

**A runnable artificial-life research prototype, not a scripted animal game.**

The system creates an ecological world of digital organisms. Each organism has a tiny **16-weight inherited motor controller**. It senses food availability ahead, to its left and right, its own stored energy, and nearby crowding; its controller produces two outputs: *turn* and *speed*. The program does **not** contain an `if food_on_left: turn_left` rule. Movement policies can spread only if organisms carrying those policies leave more surviving descendants. Organisms automatically collect available food where they stand; above an energy threshold, they automatically reproduce with a mutating copy of their controller.

The separate simulation engine runs without a graphics window, and the optional Pygame viewer makes the same agents visible. Files include automated tests, full deterministic checkpoints, reproduction lineage events, and repeated experiments.

**v0.2 update (Experiment 002):** 18 *new* training seeds replicated a harvesting improvement, then motor ablations showed that **turning off steering actually increases harvesting** in this ecosystem. The strongest established adaptation is currently faster, more effective locomotion, not intelligent navigation. Lowering food regrowth also produced an observable extinction boundary. See [`docs/EXPERIMENT_002.md`](docs/EXPERIMENT_002.md), including surprising negative results and methodological limits.

## Start on Windows

1. Install **Python 3.10 or later** with Python added to PATH (the Windows Python launcher `py` is also supported).
2. Extract the entire ZIP. Double-click **`run_windows.bat`** to install dependencies if needed and launch the Pygame microscope.
3. Or, open a terminal *inside this project folder* and run:

```powershell
py -3 -m pip install -r requirements.txt
py -3 -m biosphere view
```

This ZIP is **Python source code**, not a precompiled `.exe`. Pygame is installed on your own PC when you run the script.

### Viewer controls

- **Space** — pause/unpause simulation
- **+ / -** — double/halve simulation steps per rendered frame
- **Click an organism** — inspect its parent ID, generation, age, energy
- **F** — switch between food remaining and land carrying capacity
- **[ / ]** — decrease/increase food replenishment rate live; use **R** to restart the same seed at the chosen scarcity level
- **H** — explanatory overlay
- **S** — save full checkpoint plus screenshot to `results/viewer/`
- **R** — restart the world with the original seed
- **Esc** — exit

Screenshots are visual records; `world_*.npz` checkpoints contain the **full simulation**, including food, individual organisms, genomes and RNG state.

## Headless mode and experiments

Headless mode only requires NumPy (`pip install numpy`), and runs without Pygame.

```powershell
py -3 -m biosphere run --seed 5 --steps 3000 --events --output results/my_world
py -3 -m biosphere run --resume results/my_world/world.npz --steps 1000 --output results/continued
py -3 -m biosphere experiment --seeds 6 --steps 1200 --probe-ticks 180 --output results/my_experiment
py -3 -m biosphere investigate --seed-start 101 --seeds 18 --steps 1200 --probe-ticks 240 --output results/my_investigation
py -3 -m pytest -q
```

**The checked-in experiment** is already in `results/experiment_6seed/` and includes:

| File | What it is |
| --- | --- |
| `summary.json` | Treatment means, paired differences, bootstrap intervals |
| `probe_trials.csv` | Every treatment result for all 6 seeds |
| `training_history.csv` | Time-series populations and genomes stats |
| `common_garden.png` | Raw replicate outcomes and treatment means |
| `population_dynamics.png` | Training populations, mutation vs no mutation |
| `evolved_seed_1.npz` ... `evolved_seed_6.npz` | Resumable evolved worlds, full state |

`results/lineage_demo/lineage.csv` also contains birth and death events with organism IDs, parent IDs and generations. `results/ecosystem_snapshot.png` is an actual rendering of evolved seed 1, step 1200. The snapshot is **not** a test of the Pygame window itself.

### Experiment 002 files

`results/experiment_002/` includes `summary.json`, independent-seed outcomes in `training_outcomes.csv`, head-to-head interventions in `probe_trials.csv`, controlled cue-response measurements in `controller_responses.csv`, interpretable effective motor weights in `effective_genes.csv`, figures, and **36 restorable evolved worlds** from two selected regrowth conditions. This second experiment used new training seeds **101–118** and five levels of food regrowth.

The main result is a challenge to a simplistic interpretation: evolving stronger responses to side-specific food cues is **not** equivalent to evolving superior navigation. In these novel-test gardens, fixed zero-turn agents harvested more food than normally turning evolved agents. That result is described and tested in detail in `docs/EXPERIMENT_002.md`.

## First observed result

In a **six-seed exploratory experiment**, evaluating each group in fresh environments with otherwise matched conditions:

- Founder mean harvest: **0.4621** food units / starting organism / step.
- Evolved mean harvest: **0.5873** (+27.1% over founders).
- Evolved with external senses removed: **0.5244** (worse than evolved unblinded).
- Founder with external senses removed: **0.4277**.
- Evolved without new mutations: **0.5921**, statistically too close on these six seeds to conclude that mutation helped or hurt.
- Mean movement speed increased from **0.488** (founders) to **0.713** (evolved), suggesting selection favored greater movement in this ecology.
- Difference in external-sensor benefit between evolved and founders: **+0.0286** units / organism / tick (paired bootstrap 95% interval **[0.0167, 0.0398]**).

This is evidence for improved, heritable **sensorimotor resource harvesting**, with an increased benefit from external sensing. It does **not** demonstrate animal intelligence or evolved cooperation. The simulation was prototyped and tuned before this evaluation; all numbers here are **exploratory**, not a preregistered finding. See `docs/EXPERIMENT_001.md` for experimental design, limitations and uncertainty.

## Under the hood

- World: **72 x 54 toroidal spatial grid**, randomly generated stationary food-capacity patches, local depletion and regrowth.
- Brain: **2 motor neurons × 8 input channels**, randomized at foundation, cloned to offspring with independent parameter mutations.
- Life cycle: stored energy, fuel expenditure for existence and motion, automatic harvesting, energy-costly asexual reproduction, finite life and starvation.
- Ecology: offspring begin close to parent, compete for food, and inherit the parent's controller. There is no artificial rescuer if all organisms die.
- Population cap: default **900** simultaneous organisms.
- Logging: genome variance, population, deaths, births, lineage depth, resource stock, harvesting, movement, and controller response.
- Reproducibility: NumPy PRNG seed recorded in checkpoint, together with its internal state; restart is bitwise tested.

**No behavior is guaranteed to emerge.** The world is deliberately simple and constrained. Organisms cannot currently communicate, attack, form families, learn during life, develop new body plans, or create complex social systems. Results do not demonstrate open-ended Darwinian innovation.

## Documentation

- `docs/RESEARCH.md`: literature review and source provenance (Tierra, Avida, Polyworld).
- `docs/MODEL.md`: formal rules, input/output semantics and engineering tradeoffs.
- `docs/EXPERIMENT_001.md`: hypothesis, design, data, results, limitations, further tests.
- `docs/EXPERIMENT_002.md`: motor ablation, controller-weight, scarcity and extinction tests.
- `docs/JOURNAL.md`: dated research log of observations, failures and changes.
- `docs/QA.md`: automated tests and verification status.

## Optional experiment re-render

From the project folder:

```powershell
py -3 experiments/plot_snapshot.py results/experiment_6seed/evolved_seed_1.npz results/new_snapshot.png
```

You may run the original checkpoint for many more generations and save the result. Do not confuse tick count with generational count: generations are calculated from parent-child lineage, and many overlapping generations coexist.

## Project layout

```text
biosphere/                 Source: engine, CLI, viewer, experiments
experiments/               Snapshot rendering utility
tests/                     Reproducible automated correctness tests
docs/                      Research, methods, journal, QA
results/                   Real simulation output and controls
run_windows.bat            Windows start shortcut
requirements.txt           Python dependencies
pyproject.toml             Installable Python project
```

License: this prototype's new source code is offered under the MIT License in `LICENSE`. Research references are **not** included as redistributed third-party source code.

## Interpretation warning for v0.2

The follow-up corrected an intuitive but unsupported story. The agents became better at finding food in aggregate, but **zeroing their steering increased harvest even further**; the system does not yet exhibit effective directional foraging as a learned strategy. Any future changes to the world physics must be evaluated in controlled, separate experiments before claims of emergent intelligence.
