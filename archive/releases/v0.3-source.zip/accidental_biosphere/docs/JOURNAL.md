# Research journal

### 2026-11-02 — Background and build decision

Reviewed Tierra (digital self-replicating programs), Avida (controlled digital-evolution studies), and Polyworld (neurally controlled organisms in an ecology). Chose a simpler visible sensorimotor model with NumPy simulation and a separate Pygame window. Aim: make claims only about heritable adaptive controller changes, not synthetic cognitive life.

### 2026-11-02 — First code tests: patch saturation failure

Initial small-world terrain generator used 27 random overlapping resource hills regardless of world size. On a 22×18 test map, practically every cell hit the maximum capacity. Different random seeds became indistinguishable, and a test caught it. **Fix:** scale the number of hills to world area. Also changed sensor readings from percentage of maximum capacity to **absolute food stock**; percentages initially gave identical sensor readings everywhere on a fully replenished map, erasing the very gradient being studied. These are architectural corrections, not evolutionary discoveries.

### 2026-11-02 — Pilot: repeated tests

At 900 training ticks over seeds 1–3, evolved controllers outperformed initial founders in novel landscapes. However, no-mutation groups did better than mutating groups in all three of these short pilot runs. **Action:** explicitly include no-mutation controls and founder-blind trials before the primary six-seed exploratory comparison. Do not assert beneficial mutation just because a system evolves.

### 2026-11-02 — Completed Experiment 001

Ran 6 seeds × 1,200 training ticks, with six matched control treatments evaluated for 180 ticks in fresh landscapes. Average evolved harvest = 0.5873; founder = 0.4621. Removing evolved environmental senses reduced performance to 0.5244. Evolution increased sensor benefit by +0.0286 (paired bootstrap 95% interval +0.0167 to +0.0398). Mutation effect indistinguishable from zero at this scale. An additional observation: average motor speed was 0.488 for founders and 0.713 for evolved genomes across matched common gardens. This supports a simple behavioral interpretation of increased resource access through exploration, not demonstrated food-directed turning. Full methods: `EXPERIMENT_001.md`.

**Interpretation:** selection improved heritable controller behavior in a way useful for collecting resources. More evidence is needed to isolate the strategy; no cooperation or complex intelligence can be inferred.

### 2026-11-02 — Engineering validation

Added tests for deterministic seeding, resource allocation under crowding, reproduction lineage integrity, exact checkpoint continuation, blinding, extinction, mutation-disabled inheritance, invalid config, no-food energy decline, population cap, common-garden repeatability, and saved-observable recovery. Built an actual-state plotting utility. Viewer logic is written and syntax-checked, but **cannot be runtime-smoke-tested here** because Pygame isn't installed and package installation could not reach its repository.

### Open findings and failed expectations

- It was premature to expect beneficial new mutations to reliably outperform standing-variation selection in ~1,200 steps. At this horizon they did not.
- Improvement in total food collection does not tell us *how* organisms move. The next investigation must measure the stimulus-response controller directly and use richer ablations.
- The first pilot showed that simple resource-rich ecologies can quickly reach the simulation's 900-organism cap. This makes demographic selection and crowding important confounders worth manipulating.
- Despite thousands of births, the prototype has not demonstrated communication, distinct social roles or emergent predators. We will not add labels to ordinary movement to make it sound more impressive.

### 2026-11-02 — Experiment 002: mechanism tests correct an overinterpretation

Extended the simulator with reversible *experimental* sensory/motor overrides; added a static artificial-cue assay and effective-gene weight analysis (necessary because food-contrast inputs are linearly redundant). Ran **18 entirely new training seeds**, each under five regrowth conditions for 1,200 ticks; evaluated at 240 ticks on unseen terrain with 0.030/0.006 regrowth. All outcomes are in `results/experiment_002/` and methods are in `EXPERIMENT_002.md`.

**Reproducible improvement**: abundance-trained evolved genomes harvested 0.61958 compared with 0.47610 founders (+30.1%). They also increased standardized speed from 0.4726 to 0.6676, driven in part by larger inherited baseline/energy speed weights. Their motor turn response to synthetic directional cues increased in 16 of 18 seed pairs.

**Surprising negative finding**: disabling steering made evolved genomes harvest *more* (0.70574 versus 0.61958). Therefore we cannot call the evolved responses a successful food-targeting behavior. This is a falsification of the strong navigation interpretation, though not of the observed adaptive harvesting. Mirrored spatial food cues had little effect relative to complete food-sensor removal. Generic locomotor changes dominate.

**Scarcity**: slow replenishment sharply lowered long-run population. All 18 worlds at 0.001 regrowth went extinct, 8/18 at 0.003 went extinct, and all survived at 0.006. Training at 0.006 produced genomes that harvested better than abundance-trained genomes in both scarce and abundant probes; this is general transfer, not a demonstrated specialist tradeoff.

**Next:** test alternative boundary geometries and dynamic resources before broadening to more complicated neural genomes. Such a study should isolate whether rapid straight-line motion is a toroidal-map artifact.

### 2026-11-02 — Experiment 003: geometry, habitat motion, and motor costs

Preserved the inherited 16-weight controller and modified only environmental constraints: wrap versus reflecting edges, seeded relocation of carrying capacity plus stocked food every 35 ticks, and 11.5-fold higher movement-energy expenditure. Eight new training seeds (401–408) independently evolved in each of four worlds for 900 ticks; 32 resulting populations were then evaluated in 160-step holdout gardens across all four ecologies.

**Replication:** All four ecologies independently selected for better food harvesting than founders (positive in 8/8 matched training seeds per ecology). Evolution under moving food patches also produced controllers that generalize: the shifting-trained group harvested 0.6319 in the original stationary holdout, versus 0.5974 for wrap-trained. But this result is **not** a demonstrated navigation policy.

**Unexpected negative result:** Suppressing all turning still increased harvest for wrap-trained genomes in *all four* holdout ecologies, including reflecting walls (mean +0.0785 harvest) and relocated food patches (mean +0.0523). The hypothesis that removing wraparound would make normal turning superior was not supported.

**Cost hypothesis remains uncertain:** High movement costs selected controllers with lower standardized speed (0.5540 versus 0.6432 for wrap-trained genomes) and a smaller training population (400 mean versus capped 900), but a direct matched costly-ecology net-energy comparison was inconclusive. Controlled sparse-resource tasks should come before claiming food-directed behavior.

**Engineering:** Added reflecting boundary physics and reflected food sampling, seeded food/capacity relocation, exact checkpoint continuation including new state, live viewer B/M/C toggles, CLI switches, and nine additional automated tests. Full results in `EXPERIMENT_003.md` and `results/experiment_003/`.
