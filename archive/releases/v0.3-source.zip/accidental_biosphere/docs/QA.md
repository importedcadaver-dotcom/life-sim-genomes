# QA and verification

**Last automated test run: 2026-11-02. Current version: v0.3.**

| Check | Status |
| --- | --- |
| Python modules syntax check | PASS (`compileall`) |
| Identical seeds replay identically | PASS |
| Different seeds generate different terrain | PASS |
| Resource cell never becomes negative under many overlapping agents | PASS |
| Birth uses valid parent IDs and generation increment | PASS |
| Simulated reproduction cannot push above population cap | PASS |
| Checkpoint continuation equals uninterrupted simulation | PASS |
| New checkpoint preserves aggregate measurements | PASS |
| Senses can be removed for intervention | PASS |
| Extinct population remains extinct | PASS |
| Mutations disabled means genome copies are exact | PASS |
| Unphysical/invalid configurations rejected | PASS |
| No food plus metabolism reduces energy | PASS |
| Repeated common-garden evaluation with same seed is deterministic | PASS |
| Full headless CLI run and CSV/NPZ export | PASS |
| Six-seed common-garden experiment outputs data and charts | PASS |
| Independent Experiment 002: 18 seeds × 5 scarcity levels | PASS |
| Synthetic cue-response assay with known genome signs | PASS |
| Effective collapsed genes exactly reproduce raw neural dot products | PASS |
| Mirroring lateral food signals preserves all non-lateral channels | PASS |
| Independent food and crowding sensor ablations | PASS |
| Fixed speed/turn overrides preserve inherited genomes | PASS |
| Experimental motor overrides survive deterministic checkpoint continuation | PASS |
| Scarcity treatments share exact initial conditions before divergence | PASS |
| Empty/extinct training populations not silently resurrected in tests | PASS |
| Deterministic replay reproduces 57 recorded seed-101 CSV rows exactly | PASS |
| Real saved-world snapshot rendering | PASS |
| Reflecting boundary causes correct wall bounce rather than wrap | PASS |
| Food perception at walls is bounded and finite | PASS |
| Resource/capacity patch moves preserve both stocks when no eating/growth | PASS |
| Reflecting world plus moving patches checkpoint-replays exactly | PASS |
| Existing v0.2 checkpoint JSON without new keys still loads | PASS |
| New invalid boundary, shifting interval and negative cost are rejected | PASS |
| New Experiment 003 probe and causal interventions are repeatable | PASS |
| Complete miniaturized Experiment 003 emits expected files and seed contrasts | PASS |
| Headless CLI with combined walls, relocation, costly movement | PASS |
| 8 seeds × 4 training ecologies and 4 novel holdout ecologies | PASS |
| Pygame viewer actually launches and accepts B/M/C controls | **UNVERIFIED**: Pygame package unavailable here; package install blocked by DNS/network |
| Windows .bat actually launches on Windows | **UNVERIFIED**: Linux runner cannot reproduce Windows environment |
| Distribution as a precompiled Windows `.exe` | **NOT PROVIDED** |
| External review by domain scientist | **NOT DONE** |

**30 automated tests currently pass.** Tests are in `tests/test_simulation.py`, `tests/test_investigation.py`, and `tests/test_environment.py`. Run `python -m pytest -q` after extracting. In addition, seed 101 of Experiment 002 was rerun with identical parameters: all five training outcomes, 26 probe outcomes, two controller-response rows and 24 effective-gene rows were identical to the original run.

### Notes

- Deterministic tests are for the same code/runtime environment. Numerical results may vary across NumPy versions.
- Long runs reached the cap of 900 individuals; more tests are needed to quantify any cap-induced evolutionary effect.
- Stored checkpoints include NumPy arrays and serialized JSON RNG state; loading uses `allow_pickle=False`.
- Results are exploratory; six seeds in Experiment 001, 18 in Experiment 002, and eight in Experiment 003 are independent units of replication within their respective experiments.
- The first tested terrain issue is described transparently in `JOURNAL.md`.

### Experiment 003 repeatability check

After the primary eight-seed run, independent execution of seed 401 at exactly the same parameters reproduced **all 41 data rows exactly**: 4 training outcomes, 32 holdout evaluations (including ablations), and 5 controller-phenotype rows. The original and rerun CSV row values matched as strings. The runnable viewer was not tested in this environment because `pygame-ce` was unavailable and installation failed because DNS/network access was disabled.
