"""Interactive Pygame microscope for an otherwise headless scientific simulation."""
from __future__ import annotations
from dataclasses import replace
from datetime import datetime
from pathlib import Path
import math
import numpy as np
from .simulation import Config, World, SENSORS


def view(args) -> None:
    try:
        import pygame
    except ImportError as exc:
        raise SystemExit("Pygame is optional: install it using 'pip install pygame-ce'.") from exc

    pygame.init()
    W, H, margin, sidebar = 1320, 820, 23, 344
    screen = pygame.display.set_mode((W, H), pygame.RESIZABLE)
    pygame.display.set_caption("The Accidental Biosphere  |  Artificial-life microscope")
    clock = pygame.time.Clock()
    font = pygame.font.SysFont("consolas", 17)
    small = pygame.font.SysFont("consolas", 14)
    big = pygame.font.SysFont("segoeui", 27, bold=True)
    huge = pygame.font.SysFont("segoeui", 43, bold=True)
    world = World.load(args.resume) if args.resume else World(
        Config(max_population=args.max_population,
               boundary_mode=args.boundary_mode,
               patch_shift_interval=args.patch_shift_interval,
               move_cost=args.move_cost), seed=args.seed)
    startup_seed = world.seed
    regrowth_presets = (0.001, 0.003, 0.006, 0.012, 0.030)
    pause, rate, show_food, show_help = False, 3, True, False
    selected_id = None
    history = []
    last_stats = world.stats()
    bg = (13, 20, 21)
    textcolor = (228, 235, 218)
    muted = (148, 170, 159)
    accent = (181, 229, 135)

    def label(t, x, y, color=textcolor, font_override=None):
        surf = (font_override or font).render(str(t), True, color)
        screen.blit(surf, (x, y))
        return surf.get_height()

    def line(x1, y1, x2, y2, color=(45, 65, 58), width=1):
        pygame.draw.line(screen, color, (x1, y1), (x2, y2), width)

    def save():
        Path("results/viewer").mkdir(parents=True, exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        world.save(f"results/viewer/world_{stamp}.npz")
        pygame.image.save(screen, f"results/viewer/screenshot_{stamp}.png")

    def short(v, digits=1):
        return f"{v:,.{digits}f}"

    running = True
    while running:
        w, h = screen.get_size()
        field_width, field_height = max(w - sidebar - margin * 3, 120), max(h - margin * 2 - 52, 100)
        scale = min(field_width / world.config.width, field_height / world.config.height)
        pw, ph = int(world.config.width * scale), int(world.config.height * scale)
        ox, oy = margin, 77
        screen.fill(bg)
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                running = False
            elif ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    running = False
                elif ev.key == pygame.K_SPACE:
                    pause = not pause
                elif ev.key in (pygame.K_EQUALS, pygame.K_KP_PLUS):
                    rate = min(1000, 1 if rate == 0 else rate * 2)
                elif ev.key in (pygame.K_MINUS, pygame.K_KP_MINUS):
                    rate = max(1, rate // 2)
                elif ev.key == pygame.K_f:
                    show_food = not show_food
                elif ev.key in (pygame.K_LEFTBRACKET, pygame.K_RIGHTBRACKET):
                    # Change food regeneration in the living ecosystem without
                    # changing genome policies or replenishing food instantly.
                    current = min(range(len(regrowth_presets)),
                                  key=lambda i: abs(regrowth_presets[i] - world.config.growth_rate))
                    change = -1 if ev.key == pygame.K_LEFTBRACKET else 1
                    new_index = max(0, min(len(regrowth_presets) - 1, current + change))
                    world.config = replace(world.config, growth_rate=regrowth_presets[new_index])
                elif ev.key == pygame.K_b:
                    world.config = replace(world.config, boundary_mode=(
                        "reflect" if world.config.boundary_mode == "wrap" else "wrap"))
                elif ev.key == pygame.K_m:
                    world.config = replace(world.config, patch_shift_interval=(
                        0 if world.config.patch_shift_interval else 35))
                elif ev.key == pygame.K_c:
                    world.config = replace(world.config, move_cost=(
                        .065 if world.config.move_cost > .065 else .75))
                elif ev.key == pygame.K_h:
                    show_help = not show_help
                elif ev.key == pygame.K_s:
                    save()
                elif ev.key == pygame.K_r:
                    # Restart from the same founder seed while retaining the
                    # currently selected scarcity condition for comparisons.
                    world = World(world.config, seed=startup_seed)
                    history.clear(); selected_id = None; pause = False
            elif ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                mx, my = ev.pos
                if ox <= mx < ox + pw and oy <= my < oy + ph and world.population:
                    cx, cy = (mx - ox) / scale, (my - oy) / scale
                    dx = np.abs(world.x - cx)
                    dy = np.abs(world.y - cy)
                    if world.config.boundary_mode == "wrap":
                        dx = np.minimum(dx, world.config.width - dx)
                        dy = np.minimum(dy, world.config.height - dy)
                    k = int(np.argmin(dx ** 2 + dy ** 2))
                    selected_id = int(world.ids[k]) if dx[k] ** 2 + dy[k] ** 2 < (22 / scale) ** 2 else None

        if not pause and world.population:
            for _ in range(rate):
                last_stats = world.step()
                if world.tick % 15 == 0:
                    history.append((world.tick, world.population, world.last_mean_intake))
                    history[:] = history[-180:]
                if world.population == 0:
                    break

        label("THE ACCIDENTAL BIOSPHERE", margin, 15, accent, big)
        label("An evolving world  /  no scripted animal behaviors", margin + 425, 29, muted, small)
        label(f"Growth {world.config.growth_rate:.3f} [/]    B boundaries: {world.config.boundary_mode}"
              f"    M patch relocation: {world.config.patch_shift_interval or 'off'}"
              f"    C motion cost: {world.config.move_cost:.3f}    R restart", margin, 56, muted, small)
        # Heatmap is rendered on demand using NumPy->Pygame surface, not a static image.
        if show_food:
            richness = np.clip(world.food / 7.0, 0, 1) ** 0.55
            rgb = np.stack((22 + 95 * richness, 31 + 174 * richness, 30 + 70 * richness), axis=2).astype(np.uint8)
        else:
            richness = np.clip(world.capacity / 12.0, 0, 1) ** 0.6
            rgb = np.stack((25 + 65 * richness, 35 + 90 * richness, 37 + 35 * richness), axis=2).astype(np.uint8)
        surf = pygame.surfarray.make_surface(np.transpose(rgb, (1, 0, 2)))
        screen.blit(pygame.transform.scale(surf, (pw, ph)), (ox, oy))
        pygame.draw.rect(screen, (62, 85, 73), (ox - 1, oy - 1, pw + 2, ph + 2), 1)
        for k in range(world.population):
            px, py = ox + int(world.x[k] * scale), oy + int(world.y[k] * scale)
            gen = int(world.generation[k])
            shade = (min(250, 135 + gen * 11), max(110, 207 - gen * 4), min(240, 158 + gen * 5))
            rad = 3 if scale < 13 else 4
            pygame.draw.circle(screen, (10, 24, 24), (px, py), rad + 1)
            pygame.draw.circle(screen, shade, (px, py), rad)
            ex = px + math.cos(float(world.angle[k])) * (rad + 3)
            ey = py + math.sin(float(world.angle[k])) * (rad + 3)
            pygame.draw.line(screen, (235, 236, 210), (px, py), (ex, ey), 1)
            if selected_id is not None and int(world.ids[k]) == selected_id:
                pygame.draw.circle(screen, (255, 230, 122), (px, py), rad + 7, 2)

        sidebar_x = ox + pw + 30
        label("LIVING WORLD", sidebar_x, oy - 3, accent, font)
        line(sidebar_x, oy + 28, w - margin, oy + 28)
        y = oy + 44
        stats = world.stats()
        for heading, value in (("POPULATION", f"{world.population} / {world.config.max_population}"),
                               ("SIMULATION STEP", f"{world.tick:,}"),
                               ("BIRTHS / DEATHS", f"{world.total_births:,} / {world.total_deaths:,}"),
                               ("MAX GENERATION", f"{stats['max_generation']}"),
                               ("MEAN ENERGY", short(stats['mean_energy'])),
                               ("MEAN FOOD / STEP", short(stats['mean_intake'], 3)),
                               ("RESOURCE STOCK", short(stats['resource_stock'], 0)),
                               ("GENOME DIVERSITY", short(stats['genetic_diversity'], 3))):
            label(heading, sidebar_x, y, muted, small)
            label(value, sidebar_x, y + 17, textcolor, font)
            y += 47

        y += 9
        label("POPULATION HISTORY", sidebar_x, y, accent, small)
        y += 24
        graph_width = max(80, w - sidebar_x - margin)
        graph_height = 72
        pygame.draw.rect(screen, (22, 35, 34), (sidebar_x, y, graph_width, graph_height))
        if len(history) > 2:
            series = np.array([p[1] for p in history], dtype=np.float64)
            top = max(float(np.max(series)), float(world.config.max_population) * 0.5, 1)
            coords = [(sidebar_x + i / (len(series) - 1) * (graph_width - 4),
                       y + graph_height - 4 - p / top * (graph_height - 8)) for i, p in enumerate(series)]
            pygame.draw.lines(screen, accent, False, coords, 2)
        y += graph_height + 19

        if selected_id is not None and selected_id in world.ids:
            idx = int(np.flatnonzero(world.ids == selected_id)[0])
            label(f"SPECIMEN  #{selected_id}", sidebar_x, y, (255, 222, 134), font)
            y += 26
            for title, val in (("Parent", int(world.parents[idx])), ("Generation", int(world.generation[idx])),
                               ("Age", int(world.age[idx])), ("Energy", round(float(world.energy[idx]), 2))):
                label(f"{title}: {val}", sidebar_x, y, muted, small); y += 21
            label("Click another organism to inspect", sidebar_x, y + 3, muted, small)
        else:
            label("CLICK AN ORGANISM", sidebar_x, y, muted, font)
            label("Inspect its ID, parent and genome era", sidebar_x, y + 27, muted, small)

        footer_y = h - 40
        line(margin, footer_y - 13, w - margin, footer_y - 13)
        label(f"{'PAUSED' if pause else 'RUNNING'}  {rate} steps/frame   SPACE pause   +/- speed   [/] regrowth   B walls   M move patches   C motion cost   S save   H help   R restart   ESC",
              margin, footer_y, accent if not pause else (255, 215, 135), small)
        if world.population == 0:
            label("EXTINCTION  /  the ecosystem has no survivors", ox + 25, oy + 30, (255, 185, 133), big)
        if show_help:
            rect = pygame.Rect(ox + 25, oy + 25, min(660, pw - 50), 305)
            pygame.draw.rect(screen, (21, 33, 34), rect, border_radius=7)
            pygame.draw.rect(screen, accent, rect, 1, border_radius=7)
            label("HOW TO READ THE WORLD", rect.x + 17, rect.y + 14, accent, font)
            for j, text in enumerate(("Green terrain: food remaining in each grid cell",
                                      "Dots: individual organisms; direction line: movement",
                                      "Color: lineage generation (not species identity)",
                                      "Each dot has a mutable inherited 16-weight brain",
                                      "No hardcoded hunting, teamwork, or route finding",
                                      "[ / ] change resource regrowth without resetting food",
                                      "B toggles wrap or reflecting walls; M moves patches",
                                      "C changes movement cost; R restarts this ecology",
                                      "Shifted food/capacity conserve resource stock at each shift")):
                label(text, rect.x + 17, rect.y + 48 + j * 26, textcolor, small)
        pygame.display.flip()
        clock.tick(40)
    pygame.quit()
